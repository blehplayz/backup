#pragma once

uintptr_t m_Il2Cpp;
uintptr_t m_Anogs;

void *BaseWorld_Instance = 0;

enum TouchPhase {
	Began = 0,
	Moved = 1,
	Stationary = 2,
	Ended = 3,
	Canceled = 4,
};

enum TouchType {
	Direct = 0,
	Indirect = 1,
	Stylus = 2,
};

struct Touch {
	int m_FingerId;
	Vector2 m_Position;
	Vector2 m_RawPosition;
	Vector2 m_PositionDelta;
	float m_TimeDelta;
	int m_TapCount;
	TouchPhase m_Phase;
	TouchType m_Type;
	float m_Pressure;
	float m_maximumPossiblePressure;
	float m_Radius;
	float m_RadiusVariance;
	float m_AltitudeAngle;
	float m_AzimuthAngle;
};

enum LineTarget {
    Top = 0,
    Center = 1
};

enum Health1 {
    HTop = 0,
    Side = 1
};


enum EAim {
  Distance = 0,
  Crosshair = 1
};
enum EAimTarget {
    Heads = 0,
    Chests = 1,
    Body = 2,
};

enum EAimTrigger {
    None = 0,
    Shooting = 1,
    Scoping = 2
    
};
enum BoxNig {
    Box = 0,
    Cen = 1
    
};
struct sConfig {
	struct sInitImGui {
		bool g_Initialized;
		bool clearMousePos = true;
		uintptr_t thiz;
	};
	sInitImGui ImGuiMenu{0};
	

	struct sESPMenu {
        bool ESP;
        bool Count;
        bool isPlayerName;
        bool isPlayerLine;
        LineTarget Target;
      bool Proc;
      Health1 Heal;
      BoxNig Boxer;
        bool isPlayerBox;
        bool isPlayerHealth;
        bool isPlayerDist;
        bool Skelton;
		bool Vehicle;
		bool VehicleBox;
    };
	sESPMenu ESPMenu{0};
	
      
  struct sAim {
        bool Enable;
        EAimTarget Target;
        EAimTrigger Trigger;
        EAim By;
        float Size;
        bool SilentBot;
    };
  
    sAim Aim{0};
	
	struct sColorsESP {
        float *LineC;
        float *BoxC;
        float *NameC;
        float *PovC;
        float *HealthC;
        float *DistanceC;
    };
    sColorsESP ColorsESP{0};
	
	struct sExtraMenu {
		bool Bypass;
		bool Wallhack;
		bool Outline;
		bool Reload;
		bool Recoil;
		bool Spread;
		bool Hitmark;
		bool Scope;
		bool Switch;
		bool Buff;
		bool Heat;
		bool Fovcross;
		bool Smallcross;
		bool Swim;
		bool Parachute;
		bool Cost;
		bool Fire;
		bool Auto;
		bool Rate;
		bool Spectator;
		bool Uav;
		bool Night;
		bool Lowbt;
		bool Ultra;
		bool Show;
		bool Locked;
		bool Somo;
		bool Dinz;
		bool AimAssist;
		float SizeAim;
		bool AimAssist2;
		float SizeAim2;
		bool Slide;
		bool Unli;
		float SizeSlide;
		bool Jump;
        float SizeJump;
		bool Speed;
		float SizeSpeed;
        bool Clear;
		bool Tutorial;
		bool Lobby;
        
		bool Bang;
		bool Oden;
		bool Holger;
		bool Dark;
		
		
		bool Sniper;
		
		bool Hitbox;
		
		
		
		
		bool Fps;
		bool Byp;
        
        
        bool Framerate;
        
        
        bool Krm;
        bool Dlq2;
        bool Nik;
        bool Sop;
        bool Spec;      
        bool Tang;
        
        bool Mark;
        bool Ali;
        bool Buf;
        bool Pan;
        bool Dlq22;
        bool Hid;
        
        
        bool Mol;
        
        bool Kol;
        
        
        bool Ass;
        bool Diam;
		
        bool Dlq;
        bool Cb;
	};
	sExtraMenu ExtraMenu{0};
};

sConfig Config{0};
