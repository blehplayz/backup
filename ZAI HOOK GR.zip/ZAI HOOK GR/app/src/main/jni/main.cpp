#include "Includes/Logger.h"
#include "Includes/obfuscate.h"
#include "Includes/Utils.h"
#include "ImGui/Call_ImGui.h"
#include "IL2CppSDKGenerator/BasicStructs/Call_BasicStructs.h"
#include "IL2CppSDKGenerator/IL2Cpp/Call_IL2Cpp.h"
#include "Hacks/Hacks.h"
#include "Hook/KittyMemory/MemoryPatch.h"
#include "ImGui/imgui.h"
#include "ImGui/imgui_additional.h"
#include "ZaiModz/include/ScanEngine.hpp"
#include "ZaiModz/enc/StrEnc.h"
#include "ZaiModz/enc/json.hpp"
#include "ZaiModz/enc/md5.h"
#include "curl/curl.h"
#include "ZaiModz/enc/Oxorany.h"
#include "Includes/Macros.h"

#define __int8 char
#define __int16 short
#define __int32 int
#define __int64 long long

#define _BYTE uint8_t
#define _WORD  uint8_t
#define _DWORD uint32_t
#define _QWORD uint64_t
#define _BOOL4 uint8_t

typedef unsigned char byte;
typedef unsigned char BYTE;  // Define BYTE 
typedef bool _BOOL8;
typedef BYTE* PBYTE;  // Pointer to BYTE.
#define Owner = "@zaiofficial" // Fixed and updated to advanced by @zaiofficial | 
#define PackageName "com.garena.game.codm" //CODM GR
//#define PackageName "com.vng.codmvn" // CODM VNG

#define Libunity OBFUSCATE("libunity.so")
#define Libanort OBFUSCATE("libanort.so")
#define Libanogs OBFUSCATE("libanogs.so")
#define Libc OBFUSCATE("libc.so")
#define Libegl OBFUSCATE("libEgl.so")
#define Libgcloud OBFUSCATE("libgcloud.so")
#define Libtdata OBFUSCATE("libTDataMaster.so")
#define Libcrashsight OBFUSCATE("libCrashSight.so")


#define DefineHook(RET, NAME, ARGS) \
	RET(*Orig_##NAME)               \
	ARGS;                           \
	RET Hook_##NAME ARGS
	
JavaVM *jvm;
std::string CalcMD5(std::string s);
using json = nlohmann::json;


struct My_Patches {
    MemoryPatch /*MaxFPS,MaxFPS1, MaxFPS2, MaxFPS3, Aims1, Aims2,Aims3,Aims4,Aims5,Aims6, */Wol, Outline1, Outline2,/*Fastshoot1,Fastshoot2,Fastshoot3,Fastshoot4,*/Nightmode1,Nightmode2,/*Fastscope1,Fastscope2,Wireframe,*/Flashbang,/*Lb1, Lb2, Lb3, Lb4, Lb5, Lb6, Lb7, Lb8, Lb9,Lb10,Lb11,Lb12,Lb13,Lb14,Lb15,Lb16,Lb17,Lb18,Lb19,Lb20,

Guest1, Guest2,*/
Lobby1, Lobby2, Lobby3, Lobby4, Lobby5, Lobby6, Lobby7, Lobby8, Lobby9, Lobby10, Lobby11,
Skip1, Skip2,
Mediumaim1, Mediumaim2,
Norwall,
Hit1, Hit2,
/*Fovcross1, Fovcross2,
Spec1, Spec2, Spec3, Spec4,
Lowbt1, Lowbt2, Lowbt3, Lowbt4,*/
Dark1, Dark2,
Opti1, Opti2, Opti3, Opti4/*,
Frame1, Frame2, Frame3, Frame4,
Showfps1, Showfps2*/
;
} hexPatches;

/*struct My_Patches {
    MemoryPatch
//Norwall,
//Frame1, Frame2, Frame3, Frame4
;
} hexPatches;*/

bool Buff, Krm, Tang, Dlq2, Dlq, Kol, Cb, Nik, Sop, Spec, He1, Off, Buf, Ali, Dl, Pha, Oden, Holger, Diam, Ass = false;
uintptr_t address = 0;
uintptr_t address2 = 0;
using namespace kFox;
uintptr_t g_il2cpp;
std::string g_Token, g_Auth;
bool bValid = false;

#define CREATE_COLOR(r, g, b, a) new float[4] {(float)r, (float)g, (float)b, (float)a};


#define CREATE_COLOR(r, g, b, a) new float[4] {(float)r, (float)g, (float)b, (float)a};

std::string getClipboard() {
    std::string result;
    JNIEnv *env;

    VM->AttachCurrentThread(&env, NULL);

    auto looperClass = env->FindClass(OBFUSCATE("android/os/Looper"));
    auto prepareMethod = env->GetStaticMethodID(looperClass, OBFUSCATE("prepare"),
                                                OBFUSCATE("()V"));
    env->CallStaticVoidMethod(looperClass, prepareMethod);

    jclass activityThreadClass = env->FindClass(OBFUSCATE("android/app/ActivityThread"));
    jfieldID sCurrentActivityThreadField = env->GetStaticFieldID(activityThreadClass, OBFUSCATE(
            "sCurrentActivityThread"), OBFUSCATE("Landroid/app/ActivityThread;"));
    jobject sCurrentActivityThread = env->GetStaticObjectField(activityThreadClass,
                                                               sCurrentActivityThreadField);

    jfieldID mInitialApplicationField = env->GetFieldID(activityThreadClass,
                                                        OBFUSCATE("mInitialApplication"),
                                                        OBFUSCATE("Landroid/app/Application;"));
    jobject mInitialApplication = env->GetObjectField(sCurrentActivityThread,
                                                      mInitialApplicationField);

    auto contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    auto getSystemServiceMethod = env->GetMethodID(contextClass, OBFUSCATE("getSystemService"),
                                                   OBFUSCATE(
                                                           "(Ljava/lang/String;)Ljava/lang/Object;"));

    auto str = env->NewStringUTF(OBFUSCATE("clipboard"));
    auto clipboardManager = env->CallObjectMethod(mInitialApplication, getSystemServiceMethod, str);
    env->DeleteLocalRef(str);

    jclass ClipboardManagerClass = env->FindClass(OBFUSCATE("android/content/ClipboardManager"));
    auto getText = env->GetMethodID(ClipboardManagerClass, OBFUSCATE("getText"),
                                    OBFUSCATE("()Ljava/lang/CharSequence;"));

    jclass CharSequenceClass = env->FindClass(OBFUSCATE("java/lang/CharSequence"));
    auto toStringMethod = env->GetMethodID(CharSequenceClass, OBFUSCATE("toString"),
                                           OBFUSCATE("()Ljava/lang/String;"));

    auto text = env->CallObjectMethod(clipboardManager, getText);
    if (text) {
        str = (jstring) env->CallObjectMethod(text, toStringMethod);
        result = env->GetStringUTFChars(str, 0);
        env->DeleteLocalRef(str);
        env->DeleteLocalRef(text);
    }

    env->DeleteLocalRef(CharSequenceClass);
    env->DeleteLocalRef(ClipboardManagerClass);
    env->DeleteLocalRef(clipboardManager);
    env->DeleteLocalRef(contextClass);
    env->DeleteLocalRef(mInitialApplication);
    env->DeleteLocalRef(activityThreadClass);
    VM->DetachCurrentThread();
    return result.c_str();
}

//Fixed and updated to advanced by @zaiofficial | 
//=================================================================\\

struct MemoryStruct {
    char *memory;
    size_t size;
};

static size_t WriteMemoryCallback(void *contents, size_t size, size_t nmemb, void *userp) {
    size_t realsize = size * nmemb;
    auto *mem = (struct MemoryStruct *) userp;

    mem->memory = (char *) realloc(mem->memory, mem->size + realsize + 1);
    if (mem->memory == nullptr) {
        return 0;
    }

    memcpy(&(mem->memory[mem->size]), contents, realsize);
    mem->size += realsize;
    mem->memory[mem->size] = 0;

    return realsize;
}

const char *GetAndroidID(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    jmethodID getContentResolverMethod = env->GetMethodID(contextClass,
                                                          OBFUSCATE("getContentResolver"),
                                                          OBFUSCATE(
                                                                  "()Landroid/content/ContentResolver;"));
    jclass settingSecureClass = env->FindClass(OBFUSCATE("android/provider/Settings$Secure"));
    jmethodID getStringMethod = env->GetStaticMethodID(settingSecureClass, OBFUSCATE("getString"),
                                                       OBFUSCATE(
                                                               "(Landroid/content/ContentResolver;Ljava/lang/String;)Ljava/lang/String;"));
    auto obj = env->CallObjectMethod(context, getContentResolverMethod);
    auto str = (jstring) env->CallStaticObjectMethod(settingSecureClass, getStringMethod, obj,
                                                     env->NewStringUTF(OBFUSCATE("android_id")));
    return env->GetStringUTFChars(str, nullptr);
}

const char *GetDeviceModel(JNIEnv *env) {
    jclass buildClass = env->FindClass(OBFUSCATE("android/os/Build"));
    jfieldID modelId = env->GetStaticFieldID(buildClass, OBFUSCATE("MODEL"),
                                             OBFUSCATE("Ljava/lang/String;"));
    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, nullptr);
}

const char *GetDeviceBrand(JNIEnv *env) {
    jclass buildClass = env->FindClass(OBFUSCATE("android/os/Build"));
    jfieldID modelId = env->GetStaticFieldID(buildClass, OBFUSCATE("BRAND"),
                                             OBFUSCATE("Ljava/lang/String;"));
    auto str = (jstring) env->GetStaticObjectField(buildClass, modelId);
    return env->GetStringUTFChars(str, nullptr);
}

const char *GetPackageName(JNIEnv *env, jobject context) {
    jclass contextClass = env->FindClass(OBFUSCATE("android/content/Context"));
    jmethodID getPackageNameId = env->GetMethodID(contextClass, OBFUSCATE("getPackageName"),
                                                  OBFUSCATE("()Ljava/lang/String;"));
    auto str = (jstring) env->CallObjectMethod(context, getPackageNameId);
    return env->GetStringUTFChars(str, nullptr);
}

const char *GetDeviceUniqueIdentifier(JNIEnv *env, const char *uuid) {
    jclass uuidClass = env->FindClass(OBFUSCATE("java/util/UUID"));
    auto len = strlen(uuid);
    jbyteArray myJByteArray = env->NewByteArray(len);
    env->SetByteArrayRegion(myJByteArray, 0, len, (jbyte *) uuid);
    jmethodID nameUUIDFromBytesMethod = env->GetStaticMethodID(uuidClass,
                                                               OBFUSCATE("nameUUIDFromBytes"),
                                                               OBFUSCATE("([B)Ljava/util/UUID;"));
    jmethodID toStringMethod = env->GetMethodID(uuidClass, OBFUSCATE("toString"),
                                                OBFUSCATE("()Ljava/lang/String;"));
    auto obj = env->CallStaticObjectMethod(uuidClass, nameUUIDFromBytesMethod, myJByteArray);
    auto str = (jstring) env->CallObjectMethod(obj, toStringMethod);
    return env->GetStringUTFChars(str, nullptr);
}


//Fixed and updated to advanced by @zaiofficial | 
//=====================================================================\\
//============================ MAIN LOGIN ============================\\
//=====================================================================\\

std::string Login(const char *user_key) {
    JNIEnv *env;
    VM->AttachCurrentThread(&env, nullptr);
    std::string hwid = user_key;
    object = getGlobalContext(env);
    hwid += GetAndroidID(env, object);
    hwid += GetDeviceModel(env);
    hwid += GetDeviceBrand(env);
    std::string UUID = GetDeviceUniqueIdentifier(env, hwid.c_str());
    VM->DetachCurrentThread();
    std::string errMsg;

    struct MemoryStruct chunk{};
    chunk.memory = (char *) malloc(1);
    chunk.size = 0;

   CURL *curl;
    CURLcode res;
    curl = curl_easy_init();

    if (curl) {
        curl_easy_setopt(curl, CURLOPT_CUSTOMREQUEST, /*POST*/ StrEnc("=lY3", "\x6D\x23\x0A\x67", 4).c_str());
        curl_easy_setopt(curl, CURLOPT_URL, "https://zaipanel.000webhostapp.com/public/connect");
                curl_easy_setopt(curl, CURLOPT_FOLLOWLOCATION, 1);
        curl_easy_setopt(curl, CURLOPT_DEFAULT_PROTOCOL, /*https*/ StrEnc("/FO(F", "\x47\x32\x3B\x58\x35", 5).c_str());
        struct curl_slist *headers = nullptr;
        headers = curl_slist_append(headers, oxorany("Accept: application/json"));
        headers = curl_slist_append(headers, oxorany("Content-Type: application/x-www-form-urlencoded"));
        headers = curl_slist_append(headers, oxorany("Charset: UTF-8"));
        curl_easy_setopt(curl, CURLOPT_HTTPHEADER, headers);
        char data[4096];
        sprintf(data, "game=CODM&user_key=%s&serial=%s", user_key, UUID.c_str());
        curl_easy_setopt(curl, CURLOPT_POST, 1);
        curl_easy_setopt(curl, CURLOPT_POSTFIELDS, data);
        curl_easy_setopt(curl, CURLOPT_WRITEFUNCTION, WriteMemoryCallback);
        curl_easy_setopt(curl, CURLOPT_WRITEDATA, (void *) &chunk);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYPEER, 0);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYHOST, 2);
        curl_easy_setopt(curl, CURLOPT_SSL_VERIFYSTATUS, 0);

        res = curl_easy_perform(curl);
        if (res == CURLE_OK) {
            try {
                nlohmann::json result = nlohmann::json::parse(chunk.memory);
                auto STATUS = std::string{oxorany("status")};
                if (result[STATUS] == true) {
                    auto DATA = std::string{oxorany("data")};
                    auto TOKEN = std::string{oxorany("token")};
                    auto RNG = std::string{oxorany("rng")};	
                    std::string token = result[DATA][TOKEN].get<std::string>();
                    time_t rng = result[DATA][RNG].get<time_t>();			
                    if (rng + 30 > time(0)) {
                        std::string auth = OBFUSCATE("CODM");
                        auth += "-";
                        auth += user_key;
                        auth += "-";
                        auth += UUID;
                        auth += "-";
                        auth += /*Vm8Lk7Uj2JmsjCPVPVjrLa7zgfx3uz9E*/ StrEnc("ZD$_K NtaM8Fu=n0fFyO;!Ae<H)*Gy4%", "\x0C\x29\x1C\x13\x20\x17\x1B\x1E\x53\x07\x55\x35\x1F\x7E\x3E\x66\x36\x10\x13\x3D\x77\x40\x76\x1F\x5B\x2E\x51\x19\x32\x03\x0D\x60", 32).c_str();;
                        std::string outputAuth = md5(auth);

                        g_Token = token;
                        g_Auth = outputAuth;
                        bValid = g_Token == g_Auth;

                        if (bValid) {

                        }
                    }
                } else {
                    auto REASON = std::string{oxorany("reason")};
                    errMsg = result[REASON].get<std::string>();
                }
            } catch (nlohmann::json::exception &e) {
                errMsg = "{";
                errMsg += e.what();
                errMsg += "}\n{";
                errMsg += chunk.memory;
                errMsg += "}";
            }
        } else {
            errMsg = curl_easy_strerror(res);
        }
    }
    curl_easy_cleanup(curl);
    //VM->DetachCurrentThread();

    return bValid ? OBFUSCATE("OK") : errMsg;
}




EGLBoolean (*old_eglSwapBuffers)(EGLDisplay dpy, EGLSurface surface);
EGLBoolean hook_eglSwapBuffers(EGLDisplay dpy, EGLSurface surface) {
	if (!Config.ImGuiMenu.g_Initialized) {
		IMGUI_CHECKVERSION();
		ImGui::CreateContext();
                ImGuiStyle *style = &ImGui::GetStyle();
        
		ImGuiIO& io = ImGui::GetIO();
		
		     style->FramePadding = ImVec2(4, 2);
    style->ItemSpacing = ImVec2(10, 2);
    style->IndentSpacing = 12;
    style->ScrollbarSize = 10;

    style->WindowRounding = 4;
    style->FrameRounding = 4;
    style->PopupRounding = 4;
    style->ScrollbarRounding = 6;
    style->GrabRounding = 4;
    style->TabRounding = 4;
                
style->Colors[ImGuiCol_Text] = ImVec4(1.0f, 0.85f, 0.4f, 0.75f); // Light-gold text
style->Colors[ImGuiCol_TextDisabled] = ImVec4(0.8f, 0.8f, 0.8f, 0.75f);
style->Colors[ImGuiCol_WindowBg] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f); // Dark grey window background with transparency
style->Colors[ImGuiCol_ChildBg] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_PopupBg] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f); // Dark gray popup background with transparency
style->Colors[ImGuiCol_Border] = ImVec4(1.0f, 0.85f, 0.4f, 0.75f); // Light-gold border
style->Colors[ImGuiCol_BorderShadow] = ImVec4(0.0f, 0.0f, 0.0f, 0.0f); // No border shadow
style->Colors[ImGuiCol_FrameBg] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.2f, 0.2f, 0.2f, 0.75f); // Slightly lighter frame background on hover
style->Colors[ImGuiCol_FrameBgActive] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f); // Even darker frame background on active
style->Colors[ImGuiCol_TitleBg] = ImVec4(0.1f, 0.1f, 0.1f, 0.65f); // Dark title background with transparency
style->Colors[ImGuiCol_TitleBgActive] = ImVec4(0.15f, 0.15f, 0.15f, 0.75f); // Dark title background when active
style->Colors[ImGuiCol_TitleBgCollapsed] = ImVec4(0.05f, 0.05f, 0.05f, 0.51f); // Dark title background when collapsed
style->Colors[ImGuiCol_MenuBarBg] = ImVec4(1.0f, 0.85f, 0.4f, 0.75f);
style->Colors[ImGuiCol_ScrollbarBg] = ImVec4(0.1f, 0.1f, 0.1f, 0.39f); // Dark scrollbar background with transparency
style->Colors[ImGuiCol_ScrollbarGrab] = ImVec4(0.2f, 0.2f, 0.2f, 0.75f);
style->Colors[ImGuiCol_ScrollbarGrabHovered] = ImVec4(0.5f, 0.5f, 0.5f, 0.75f); // Slightly lighter scrollbar grab on hover
style->Colors[ImGuiCol_ScrollbarGrabActive] = ImVec4(0.3f, 0.3f, 0.3f, 0.75f); // Even darker scrollbar grab when active
style->Colors[ImGuiCol_CheckMark] = ImVec4(1.0f, 0.85f, 0.4f, 0.75f); // Light-gold checkmark
style->Colors[ImGuiCol_SliderGrab] = ImVec4(1.0f, 0.85f, 0.4f, 0.75f); // Light-gold slider grab
style->Colors[ImGuiCol_SliderGrabActive] = ImVec4(1.0f, 0.85f, 0.4f, 0.75f);
style->Colors[ImGuiCol_Button] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_ButtonHovered] = ImVec4(0.2f, 0.2f, 0.2f, 0.75f); // Lighter button background on hover
style->Colors[ImGuiCol_ButtonActive] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_Header] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_HeaderHovered] = ImVec4(0.2f, 0.2f, 0.2f, 0.75f); // Dark header background on hover
style->Colors[ImGuiCol_HeaderActive] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_Separator] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_SeparatorHovered] = ImVec4(0.5f, 0.5f, 0.5f, 0.78f); // Light separator line on hover
style->Colors[ImGuiCol_SeparatorActive] = ImVec4(0.5f, 0.5f, 0.5f, 0.75f); // Light separator line when active
style->Colors[ImGuiCol_ResizeGrip] = ImVec4(1.0f, 0.85f, 0.4f, 0.25f); // Light-gold resize grip with some transparency
style->Colors[ImGuiCol_ResizeGripHovered] = ImVec4(1.0f, 0.85f, 0.4f, 0.67f); // Light-gold resize grip on hover
style->Colors[ImGuiCol_ResizeGripActive] = ImVec4(1.0f, 0.85f, 0.4f, 0.95f); // Light-gold resize grip when active
style->Colors[ImGuiCol_Tab] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_TabHovered] = ImVec4(0.6f, 0.6f, 0.6f, 0.80f); // Light gray tab background on hover
style->Colors[ImGuiCol_TabActive] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_TabUnfocused] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_TabUnfocusedActive] = ImVec4(0.1f, 0.1f, 0.1f, 0.75f);
style->Colors[ImGuiCol_PlotLines] = ImVec4(0.61f, 0.61f, 0.61f, 0.75f); // Gray plot lines
style->Colors[ImGuiCol_PlotLinesHovered] = ImVec4(1.0f, 0.43f, 0.35f, 0.75f); // Red plot lines on hover
style->Colors[ImGuiCol_PlotHistogram] = ImVec4(0.90f, 0.70f, 0.0f, 0.75f); // Yellow plot histogram
style->Colors[ImGuiCol_PlotHistogramHovered] = ImVec4(1.0f, 0.60f, 0.0f, 0.75f); // Orange plot histogram on hover
style->Colors[ImGuiCol_TextSelectedBg] = ImVec4(0.6f, 0.6f, 0.6f, 0.35f); // Light gray text selection background
style->Colors[ImGuiCol_DragDropTarget] = ImVec4(1.0f, 0.8f, 0.0f, 0.90f); // Yellowish orange drag and drop target
style->Colors[ImGuiCol_NavHighlight] = ImVec4(1.0f, 0.85f, 0.4f, 0.75f);
style->Colors[ImGuiCol_NavWindowingHighlight] = ImVec4(1.0f, 1.0f, 1.0f, 0.70f); // White windowing highlight
style->Colors[ImGuiCol_NavWindowingDimBg] = ImVec4(0.8f, 0.8f, 0.8f, 0.20f); // Light gray windowing background with transparency
style->Colors[ImGuiCol_ModalWindowDimBg] = ImVec4(0.8f, 0.8f, 0.8f, 0.35f); // Light gray modal window background with transparency

	
        style->ScrollbarSize *= 1;
        
        ImGui_ImplOpenGL3_Init("#version 300 es");
        
        //ImFontConfig cfg;
        //cfg.SizePixels = ((float) get_density() / 20.0f);
        static const ImWchar ranges[] = { 
        0x0020, 0x00FF, 
        0x4E00, 0x9FBF,
        0x4E00, 0x62FF, 
        0x6300, 0x77FF, 
        0x7800, 0x8CFF, 
        0x8D00, 0x9FFF,
        0x0100, 0x017F,
        0x2E00, 0x2E7F,      
        0x3040, 0x309F,
        0x3000, 0x30FF,
        0x3300, 0x33FF,
        0x0180, 0x024F,
        0x31F0, 0x31FF,
        0xFF00, 0xFFEF,
        0x2600, 0x26FF,
        0xFFFD, 0xFFFD,
        0xFFF0, 0xFFFF,
        0x3041, 0x3096, 
        0x30A0, 0x30FF, 
        0x3400, 0x4DB5, 
        0x4E00, 0x9FCB, 
        0xF900, 0xFA6A,
        0x2E80, 0x2FD5, 
        0xFF5F, 0xFF9F, 
        0x3000, 0x303F,
        0x3220, 0x3243,
        0x3280, 0x337F,
        0xFF01, 0xFF5E,
        0x3400, 0x4DBF,
        0x2010, 0x205E,
        0x0E00, 0x0E7F,
        0
        }; 
    ImFontConfig font_cfg;
        io.Fonts->AddFontFromMemoryCompressedTTF(GoogleSans_compressed_data, GoogleSans_compressed_size, 24.0f/*(float) get_dpi() / 14.0f*/, &font_cfg);
        ImGui::GetStyle().ScaleAllSizes(3.0f);
        memset(&Config, 0, sizeof(sConfig));
        Config.ColorsESP.PovC = CREATE_COLOR(255,255,255,255);
        Config.ColorsESP.LineC = CREATE_COLOR(0, 255, 0, 0);
        Config.ColorsESP.BoxC = CREATE_COLOR(255, 0, 0, 255);
        Config.ColorsESP.NameC = CREATE_COLOR(255, 255, 255, 100);
        Config.ColorsESP.DistanceC = CREATE_COLOR(255, 225, 0, 255);
        Config.ColorsESP.HealthC = CREATE_COLOR(255, 0, 255, 255);
        Config.ImGuiMenu.g_Initialized = true;
    }
    
    ImGuiIO* io = &ImGui::GetIO();
    ImGui_ImplOpenGL3_NewFrame();
    ImGui_ImplAndroid_NewFrame(get_width(), get_height());
    ImGui::NewFrame();
    io->KeysDown[io->KeyMap[ImGuiKey_UpArrow]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_DownArrow]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_LeftArrow]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_RightArrow]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_Tab]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_Enter]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_Backspace]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_PageUp]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_PageDown]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_Escape]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_Delete]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_Home]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_End]] = false;
    io->KeysDown[io->KeyMap[ImGuiKey_Insert]] = false;
    ImGui::SetNextWindowSize(ImVec2((float) get_width() * 0.45f, (float) get_height() * 0.60f), ImGuiCond_Once);
    DrawESP(ImGui::GetBackgroundDrawList(), get_width(), get_height(),get_density());
	
    
 if (ImGui::Begin(OBFUSCATE("ZAI VIP V2 | CODM 1.×.40 | BUY KEY : @zaiofficial")), 0, ImGuiWindowFlags_AlwaysAutoResize) {        
        static bool isLogin = false, logginIn = false;
        static std::string err;
		
        if (!isLogin) {
            ImGui::Text(OBFUSCATE(" Please Login! (Copy Key to Clipboard)"));
            ImGui::Text(OBFUSCATE(" Key Is On My Telegram : @zaiofficialch"));
            ImGui::PushItemWidth(-1);
            static char s[150];
            ImGui::InputText("##key", s, sizeof s);
            
            ImGui::PopItemWidth();
            ImGui::PushItemWidth(-1);
            if (ImGui::Button(OBFUSCATE(" Paste Key  "), ImVec2(ImGui::GetWindowContentRegionWidth(), 0))) {
                auto key = getClipboard();
                strncpy(s, key.c_str(), sizeof s);
            }
            ImGui::PopItemWidth();
            
            ImGui::PushItemWidth(-1);
            
            if (ImGui::Button(OBFUSCATE("Login"), ImVec2(ImGui::GetWindowContentRegionWidth(), 0))) {
                err = Login(s);
                if (err == "OK") {
                    isLogin = bValid && g_Auth == g_Token;
                }
            }
            ImGui::PopItemWidth();
            
            if (!err.empty() && err != std::string(OBFUSCATE("OK"))) {
                ImGui::Text(OBFUSCATE("Error: %s"), err.c_str());
            }
            ImGui::PopItemWidth();
			
            } else {
			
		   {
		 
     if (ImGui::BeginTabBar("Tab", ImGuiTabBarFlags_FittingPolicyScroll)) {
         
                
                /*if (ImGui::BeginTabItem("ImGui Menu")) {
                    ImGui::BeginGroupPanel("ImGui Internal Fps", ImVec2(0.0f, 0.0f));
                    ImGui::Text("Ping - (%.3f ms) / Framerate - (%.1f FPS)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
                    ImGui::Spacing();
					ImGui::Checkbox("Enable Optimize Fps", &Config.ExtraMenu.Framerate);
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();
				
					ImGui::BeginGroupPanel("Memory Hacks", ImVec2(0.0f, 0.0f));
					ImGui::Checkbox("Player Outline", &Config.ExtraMenu.Outline);
                    ImGui::SameLine();
					ImGui::Checkbox("Fast Scope", &Config.ExtraMenu.Scope);
                    ImGui::SameLine();
                    ImGui::Checkbox("Fast Switch", &Config.ExtraMenu.Switch);
					ImGui::Spacing();
					ImGui::EndGroupPanel();
					
					ImGui::BeginGroupPanel("Aimbot Menu", ImVec2(0.0f, 0.0f));
                    ImGui::Checkbox("Aim Assist Rifle", &Config.ExtraMenu.AimAssist);
                    ImGui::SliderFloat("Set Rifle", &Config.ExtraMenu.SizeAim, 0.0f, 300.0f);
                    ImGui::Checkbox("Aim Assist Sniper", &Config.ExtraMenu.AimAssist2);
                    ImGui::SliderFloat("Set Sniper", &Config.ExtraMenu.SizeAim2, 0.0f, 300.0f);
                    ImGui::Spacing();
					ImGui::EndGroupPanel();
					ImGui::BeginGroupPanel("Select Theme", ImVec2(0.0f, 0.0f));
				    //ImGui::Text(OBFUSCATE(" Select Theme;"));
                    static int e = 1;
                    ImGui::RadioButton("Purple", &e, 1);
                    ImGui::SameLine();
                    ImGui::RadioButton("Blue", &e, 2);
                    ImGui::SameLine();
                    ImGui::RadioButton("White", &e, 3);
	
            switch (e) {
                  case 1:
				    ImGui::StyleColorsClassic();	        
                       break;
                                
				  case 2:
				    ImGui::StyleColorsDark();
			           break;
			 
                  case 3:
				    ImGui::StyleColorsLight();
					   break;						    
					}
		            
					ImGui::EndGroupPanel();
                    ImGui::EndTabItem();     
                    ImGui::EndTabBar();
		        }
}
				
                    if (ImGui::BeginTabItem("| Credits |")) {
                    ImGui::BeginGroupPanel("ZAI OFFICIAL", ImVec2(0.0f, 0.0f));
                    ImGui::Spacing();
                    ImGui::Text("MOD MADE BY : ZAI");
                    ImGui::Spacing();
                    ImGui::Text("NAME : ZAIJAN");
                    ImGui::Spacing();
                    ImGui::Text("AGE : 13");
                    ImGui::Spacing();
                    ImGui::Text("TELEGRAM : @zaiofficial");
                    ImGui::Spacing();
                    ImGui::Text("TELEGRAM GROUP : @zaiofficialch");
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();
                    ImGui::EndTabItem();
                    }*/
				
                    if (ImGui::BeginTabItem("| Esp |")) {
                    ImGui::BeginGroupPanel("ImGui Internal", ImVec2(0.0f, 0.0f));
                    ImGui::Text("Ping - (%.3f ms)", 1000.0f / ImGui::GetIO().Framerate, ImGui::GetIO().Framerate);
                    ImGui::Spacing();
					ImGui::Checkbox("Enable Optimize Fps", &Config.ExtraMenu.Framerate);
					ImGui::Spacing();
					ImGui::Checkbox("Bypass Lobby", &Config.ExtraMenu.Lobby);
					/*ImGui::Checkbox("Ultra Frame Rate", &Config.ExtraMenu.Ultra); //crash */
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();
                    
                    ImGui::Spacing();
                    ImGui::BeginGroupPanel("Draw ESP (Extra Sensory Perception)", ImVec2(10, 20));
                    ImGui::Checkbox("Activate ESP (Disabled After Win)", &Config.ESPMenu.ESP);  
                    ImGui::Spacing();
                    ImGui::Checkbox("Player Box", &Config.ESPMenu.isPlayerBox);
                    ImGui::SameLine();
                    ImGui::Checkbox("Player Line", &Config.ESPMenu.isPlayerLine);
                    ImGui::Spacing();
                    ImGui::Checkbox("Player Alert", &Config.ESPMenu.Count);
                    ImGui::SameLine();
                    ImGui::Checkbox("Player Name", &Config.ESPMenu.isPlayerName);     
                    ImGui::Spacing();
	                ImGui::Checkbox("Player Distance", &Config.ESPMenu.isPlayerDist);
                    ImGui::SameLine();
                    ImGui::Checkbox("Player Health", &Config.ESPMenu.isPlayerHealth);     
					ImGui::Spacing();
                    ImGui::Text("Box Style :");
                    static const char *FT_BoxNig[] = {"Filled", "Corner"};
                    ImGui::Combo("##Box", (int *) &Config.ESPMenu.Boxer, FT_BoxNig, 2, -1);
                    ImGui::Text("Health Location :");
                    static const char *FT_Health[] = {"Top", "Side"};
                    ImGui::Combo("##Health", (int *) &Config.ESPMenu.Heal, FT_Health, 2, -1); 
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();              
                    ImGui::EndTabItem();            
                }
	    
				/*if (ImGui::BeginTabItem("Memory Hacks")) {
                    ImGui::Spacing();
                    ImGui::BeginGroupPanel("Internal Memory Hacks", ImVec2(0.0f, 0.0f));
					ImGui::Checkbox("Wallhack", &Config.ExtraMenu.Wallhack);
                    ImGui::SameLine();
                    ImGui::Checkbox("Outline", &Config.ExtraMenu.Outline);
                    ImGui::Spacing();
					ImGui::EndGroupPanel();
					ImGui::BeginGroupPanel("Aimbot Menu", ImVec2(0.0f, 0.0f));
                    ImGui::Checkbox("Aim Assist Rifle", &Config.ExtraMenu.AimAssist);
                    ImGui::SliderFloat("Set Rifle", &Config.ExtraMenu.SizeAim, 0.0f, 300.0f);
                    ImGui::Checkbox("Aim Assist Sniper", &Config.ExtraMenu.AimAssist2);
                    ImGui::SliderFloat("Set Sniper", &Config.ExtraMenu.SizeAim2, 0.0f, 300.0f);
                    ImGui::Spacing();
					ImGui::EndGroupPanel();
					ImGui::BeginGroupPanel("Mics Hacks", ImVec2(0.0f, 0.0f));
					ImGui::Checkbox("No Recoil", &Config.ExtraMenu.Recoil);
                    ImGui::SameLine();
					ImGui::Checkbox("No Reload", &Config.ExtraMenu.Reload);
					ImGui::SameLine();
					ImGui::Checkbox("No Spread", &Config.ExtraMenu.Spread);
                    ImGui::Spacing();
					ImGui::Checkbox("Fast Scope", &Config.ExtraMenu.Scope);
                    ImGui::SameLine();
                    ImGui::Checkbox("Fast Switch", &Config.ExtraMenu.Switch);
					ImGui::SameLine();
					ImGui::Checkbox("Buff Damage", &Config.ExtraMenu.Buff);
                    ImGui::Spacing();
					ImGui::Checkbox("No Overheat Rpd", &Config.ExtraMenu.Heat);
                    ImGui::SameLine();
					ImGui::Checkbox("Small Crosshair", &Config.ExtraMenu.Smallcross);
                    ImGui::SameLine();
					ImGui::Checkbox("Advance Uav Map  ", &Config.ExtraMenu.Uav);
                    ImGui::Spacing();
					ImGui::EndGroupPanel();
					ImGui::BeginGroupPanel("Adjustable Menu", ImVec2(0.0f, 0.0f));
					ImGui::Checkbox("Long Slide", &Config.ExtraMenu.Slide);
                    ImGui::SliderFloat("Set Slide", &Config.ExtraMenu.SizeSlide, 0.0f, 3000.0f);
                    ImGui::Checkbox("High Jump", &Config.ExtraMenu.Jump);
                    ImGui::SliderFloat("Set Jump", &Config.ExtraMenu.SizeJump, 0.0f, 10.0f);
					ImGui::Checkbox("Speed Hack", &Config.ExtraMenu.Speed);
                    ImGui::SliderFloat("Set Speed", &Config.ExtraMenu.SizeSpeed, 0.0f, 30.0f);
					ImGui::Spacing();
					ImGui::EndGroupPanel();
					ImGui::EndTabItem();
                }*/
	
					
				if (ImGui::BeginTabItem("| Aim |")) {
				
				    ImGui::Spacing();
				    ImGui::BeginGroupPanel("AimBot", ImVec2(0.0f, 0.0f));
				    ImGui::Checkbox("Strong AimBot 360", &Config.Aim.SilentBot);
				    ImGui::Spacing();
					ImGui::Checkbox("Aim Smooth", &Config.ExtraMenu.Somo);
					ImGui::Spacing();
					ImGui::Spacing();
                    ImGui::Checkbox("Aim Assist Rifle", &Config.ExtraMenu.AimAssist);
                    ImGui::SliderFloat("Set Rifle", &Config.ExtraMenu.SizeAim, 0.0f, 300.0f);
                    ImGui::Checkbox("Aim Assist Sniper", &Config.ExtraMenu.AimAssist2);
                    ImGui::SliderFloat("Set Sniper", &Config.ExtraMenu.SizeAim2, 0.0f, 300.0f);
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();
                    
                    ImGui::BeginGroupPanel("Aim Bullet Track", ImVec2(0.0f, 0.0f));
                    ImGui::Checkbox("Aim Silent 360", &Config.Aim.Enable);
                    ImGui::Spacing();
                    ImGui::Text("Aim Target: ");
                    ImGui::SameLine();
                    static const char *targets[] = {"Head", "Chest", "Body"};
                    ImGui::Combo("##Target", (int *) &Config.Aim.Target, targets, 3, -1);
                    ImGui::Text("Aim Location: ");
                    ImGui::SameLine();
                    static const char *tarets[] = {"Distance", "Crosshair"};
                    ImGui::Combo("##By", (int *) &Config.Aim.By, tarets, 2, -1);
                    ImGui::Text("Aim Trigger: ");
                    ImGui::SameLine();
                    static const char *triggers[] = {"None", "Shooting", "Scoping"};
                    ImGui::Combo("##Trigger", (int *) &Config.Aim.Trigger, triggers, 3, -1);
                    ImGui::Text("Aim Fov: ");
                    ImGui::SameLine();
                    ImGui::SliderFloat("Set Fov", &Config.Aim.Size, 0, 2000);
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();
                    
                    /*ImGui::BeginGroupPanel("Strong AimBot All Guns ", ImVec2(0.0f, 0.0f));
                    ImGui::Checkbox("Strong AimBot 360", &Config.Aim.SilentBot);
					ImGui::Spacing();
                    ImGui::Text("Aim Target: ");
					ImGui::SameLine();
                    static const char *targets[] = {"Head", "Chest", "Body"};
                    ImGui::Combo("##Target", (int *) &Config.Aim.Target, targets, 3, -1);
                    ImGui::Text("Aim Location: ");
                    ImGui::SameLine();
                    static const char *tarets[] = {"Distance", "Crosshair"};
                    ImGui::Combo("##By", (int *) &Config.Aim.By, tarets, 2, -1);
                    ImGui::Text("Aim Trigger: ");
                    ImGui::SameLine();
                    static const char *triggers[] = {"None", "Shooting", "Scoping"};
                    ImGui::Combo("##Trigger", (int *) &Config.Aim.Trigger, triggers, 3, -1);
                    ImGui::Text("Aim Fov: ");
					ImGui::SameLine();
                    ImGui::SliderFloat("Set Fov", &Config.Aim.Size, 0, 500);
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();*/
					ImGui::EndTabItem();
                }
					
	            /*if (ImGui::BeginTabItem("| Misc |")) {
                    ImGui::Spacing();
                    ImGui::BeginGroupPanel("Adjustable Menu", ImVec2(0.0f, 0.0f));
					ImGui::Checkbox("Long Slide", &Config.ExtraMenu.Slide);
                    ImGui::SliderFloat("Set Slide", &Config.ExtraMenu.SizeSlide, 0.0f, 3000.0f);
                    ImGui::Checkbox("High Jump", &Config.ExtraMenu.Jump);
                    ImGui::SliderFloat("Set Jump", &Config.ExtraMenu.SizeJump, 0.0f, 10.0f);
					ImGui::Checkbox("Speed Hack", &Config.ExtraMenu.Speed);
                    ImGui::SliderFloat("Set Speed", &Config.ExtraMenu.SizeSpeed, 0.0f, 30.0f);
					ImGui::Spacing();
					ImGui::EndGroupPanel();
					
					ImGui::Spacing();
                    ImGui::BeginGroupPanel("Misc Menu 1", ImVec2(0.0f, 0.0f));
                    ImGui::Checkbox("Outline", &Config.ExtraMenu.Outline);
                    ImGui::SameLine();
                    ImGui::Checkbox("No Reload", &Config.ExtraMenu.Reload);
                    ImGui::Spacing();
                    ImGui::Checkbox("No Recoil", &Config.ExtraMenu.Recoil);
                    ImGui::SameLine();
					ImGui::Checkbox("No Spread", &Config.ExtraMenu.Spread);
                    ImGui::Spacing();
					ImGui::Checkbox("No Hitmark", &Config.ExtraMenu.Hitmark);
                    ImGui::SameLine();
                    ImGui::Checkbox("Fast Scope", &Config.ExtraMenu.Scope);
                    ImGui::Spacing();
                    ImGui::Checkbox("Fast Switch", &Config.ExtraMenu.Switch);
					ImGui::SameLine();
					ImGui::Checkbox("Small Crosshair", &Config.ExtraMenu.Smallcross);
                    ImGui::Spacing();
					ImGui::Checkbox("Fast Swimming", &Config.ExtraMenu.Swim);
                    ImGui::SameLine();
					ImGui::Checkbox("No Parachute", &Config.ExtraMenu.Parachute);
                    ImGui::Spacing();
                    ImGui::Checkbox("No Overheat Rpd", &Config.ExtraMenu.Heat);
                    ImGui::SameLine();
                    ImGui::Checkbox("Buff Damage", &Config.ExtraMenu.Buff);
                    ImGui::Spacing();
					ImGui::EndGroupPanel();
					
					ImGui::Spacing();
					ImGui::BeginGroupPanel("Misc Menu 2 ( GR Only )", ImVec2(0.0f, 0.0f));
					ImGui::Checkbox("Fov Crosshair", &Config.ExtraMenu.Fovcross);
                    ImGui::Spacing();
					ImGui::Checkbox("Weapon Instant Fire", &Config.ExtraMenu.Fire);
                    ImGui::SameLine();
					ImGui::Checkbox("Sniper Autofiring", &Config.ExtraMenu.Auto);
                    ImGui::Spacing();
					ImGui::Checkbox("Weapon Firerate", &Config.ExtraMenu.Rate);
                    ImGui::SameLine();
					ImGui::Checkbox("Spectator Br", &Config.ExtraMenu.Spectator);
                    ImGui::Spacing();
					
					ImGui::Checkbox("Skip Tutorial", &Config.ExtraMenu.Tutorial);
                    ImGui::SameLine();
					ImGui::Checkbox("Low Bullet Track  ", &Config.ExtraMenu.Lowbt);
					ImGui::Spacing();
					ImGui::Checkbox("Advance Uav Map  ", &Config.ExtraMenu.Uav);
                    ImGui::SameLine();
					ImGui::Checkbox("Night Mode", &Config.ExtraMenu.Night);
                    ImGui::SameLine();
					ImGui::Checkbox("Wallhack", &Config.ExtraMenu.Wallhack);
					ImGui::Spacing();
					ImGui::EndGroupPanel();
					

					ImGui::EndTabItem();
                }
	
                if (ImGui::BeginTabItem("| Skin |")) {
                    ImGui::BeginGroupPanel("Mythic Skins", ImVec2(0.0f, 0.0f));
                    ImGui::Spacing();
     ImGui::Checkbox("Dlq - LotusFlames", &Config.ExtraMenu.Dlq2);
     ImGui::Spacing();
     ImGui::Checkbox("Fennec - Ascended", &Config.ExtraMenu.Dlq);
     ImGui::Spacing();
     ImGui::Checkbox("Cbr4 - Amoeba", &Config.ExtraMenu.Cb);
     ImGui::Spacing();
     ImGui::Checkbox("Kilo141 - Demonsong", &Config.ExtraMenu.Kol);
     ImGui::Spacing();
     ImGui::Checkbox("Switchblade - X9 Neon Legend", &Config.ExtraMenu.Mol);
     ImGui::Spacing();
     ImGui::Checkbox("Oden - Divine Smite", &Config.ExtraMenu.Oden);
     ImGui::Spacing();
     ImGui::Checkbox("Rytec AMR - Nautillus", &Config.ExtraMenu.Holger);
     ImGui::Spacing();
     ImGui::Checkbox("Ak47 - Radiance", &Config.ExtraMenu.Tang);
     ImGui::Spacing();
     ImGui::EndGroupPanel();
     
     ImGui::SameLine();
     ImGui::BeginGroupPanel("Character Skins", ImVec2(0.0f, 0.0f));
     ImGui::Spacing();
     ImGui::Checkbox("Spectre T2 - Violet", &Config.ExtraMenu.Spec);
     ImGui::Spacing();
     ImGui::Checkbox("Gunzo - Devil Jester", &Config.ExtraMenu.Nik);
     ImGui::Spacing();
     ImGui::Checkbox("Reaper - Ashura", &Config.ExtraMenu.Sop);
     ImGui::Spacing();
     ImGui::Checkbox("Alias - Roboticist", &Config.ExtraMenu.Ali);
     ImGui::Spacing();
     ImGui::Checkbox("Outrider - Technoborn", &Config.ExtraMenu.Pan);
     ImGui::Spacing();
     ImGui::EndGroupPanel();
     
     ImGui::Spacing();
     ImGui::BeginGroupPanel("Custom Skins", ImVec2(0.0f, 0.0f));
     ImGui::Spacing();
     ImGui::Checkbox("Krm - GloriusBlade", &Config.ExtraMenu.Krm);
     ImGui::Spacing();
     ImGui::Checkbox("Dlq33 - Zealot", &Config.ExtraMenu.Dlq22);
     ImGui::Spacing();
     ImGui::Checkbox("Dlq33 - Diamond", &Config.ExtraMenu.Diam);
     ImGui::Spacing();
     ImGui::Checkbox("Melee - Butterfly Carver", &Config.ExtraMenu.Ass);
     ImGui::Spacing();
                    ImGui::EndGroupPanel();
					

                }*/
            
                if (ImGui::BeginTabItem("| Color |")) {
                    ImGui::BeginGroupPanel("Choose Floating Color", ImVec2(0.0f, 0.0f));
                    if (ImGui::Button("Purple"))
                    ImGui::StyleColorsClassic();
                    ImGui::SameLine();
                    if (ImGui::Button("White"))
                    ImGui::StyleColorsLight();
                    ImGui::SameLine();
                    if (ImGui::Button("Blue"))
                    ImGui::StyleColorsDark();
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();
                    
                    ImGui::Spacing();
                    ImGui::BeginGroupPanel("Color", ImVec2(0.0f, 0.0f));
                    ImGui::Text("Line Color :");
                    ImGui::ColorEdit3("##LineCol", Config.ColorsESP.LineC);
                    ImGui::Text("Box Color :");
                    ImGui::ColorEdit3("##BoxCol", Config.ColorsESP.BoxC);
                    ImGui::Text("Health Color :");
                    ImGui::ColorEdit3("##HealthCol", Config.ColorsESP.HealthC);
                    ImGui::Text("Distance Color :");
                    ImGui::ColorEdit3("##DistanceCol", Config.ColorsESP.DistanceC);
                    ImGui::Text("Name Color :");
                    ImGui::ColorEdit3("##NameCol", Config.ColorsESP.NameC);
                    ImGui::Text("POV Color :");
                    ImGui::ColorEdit3("##POV", Config.ColorsESP.PovC);
                    ImGui::Spacing();
                    ImGui::EndGroupPanel();
					
}
}

}
}


/*if (Config.ExtraMenu.Clear) {
hexPatches.Guest1.Modify();
hexPatches.Guest2.Modify();
} else {
hexPatches.Guest1.Restore();
hexPatches.Guest2.Restore();
}*/
if (Config.ExtraMenu.Night) {
hexPatches.Dark1.Modify();
hexPatches.Dark2.Modify();
} else {
hexPatches.Dark1.Restore();
hexPatches.Dark2.Restore();
}

if (Config.ExtraMenu.Wallhack) {
hexPatches.Norwall.Modify();
} else {
hexPatches.Norwall.Restore();
}
if (Config.ExtraMenu.Hitmark) {
hexPatches.Hit1.Modify();
hexPatches.Hit2.Modify();
} else {
hexPatches.Hit1.Restore();
hexPatches.Hit2.Restore();
}
/*if (Config.ExtraMenu.Fovcross) {
hexPatches.Fovcross1.Modify();
hexPatches.Fovcross2.Modify();
} else {
hexPatches.Fovcross1.Restore();
hexPatches.Fovcross2.Restore();
}*/
if (Config.ExtraMenu.Somo) {
hexPatches.Mediumaim1.Modify();
hexPatches.Mediumaim2.Modify();
} else {
hexPatches.Mediumaim1.Restore();
hexPatches.Mediumaim2.Restore();
}

if (Config.ExtraMenu.Somo) {
hexPatches.Lobby1.Modify();
hexPatches.Lobby2.Modify();
hexPatches.Lobby3.Modify();
hexPatches.Lobby4.Modify();
hexPatches.Lobby5.Modify();
hexPatches.Lobby6.Modify();
hexPatches.Lobby7.Modify();
hexPatches.Lobby8.Modify();
hexPatches.Lobby9.Modify();
hexPatches.Lobby10.Modify();
hexPatches.Lobby11.Modify();
} else {
hexPatches.Lobby1.Restore();
hexPatches.Lobby2.Restore();
hexPatches.Lobby3.Restore();
hexPatches.Lobby4.Restore();
hexPatches.Lobby5.Restore();
hexPatches.Lobby6.Restore();
hexPatches.Lobby7.Restore();
hexPatches.Lobby8.Restore();
hexPatches.Lobby9.Restore();
hexPatches.Lobby10.Restore();
hexPatches.Lobby11.Restore();
}
/*if (Config.ExtraMenu.Spectator) {
hexPatches.Spec1.Modify();
hexPatches.Spec2.Modify();
hexPatches.Spec3.Modify();
hexPatches.Spec4.Modify();
} else {
hexPatches.Spec1.Restore();
hexPatches.Spec2.Restore();
hexPatches.Spec3.Restore();
hexPatches.Spec4.Restore();
}
if (Config.ExtraMenu.Lowbt) {
hexPatches.Lowbt1.Modify();
hexPatches.Lowbt2.Modify();
hexPatches.Lowbt3.Modify();
hexPatches.Lowbt4.Modify();
} else {
hexPatches.Lowbt1.Restore();
hexPatches.Lowbt2.Restore();
hexPatches.Lowbt3.Restore();
hexPatches.Lowbt4.Restore();
}
if (Config.ExtraMenu.Night) {
hexPatches.Dark1.Modify();
hexPatches.Dark2.Modify();
} else {
hexPatches.Dark1.Restore();
hexPatches.Dark2.Restore();
}*/
if (Config.ExtraMenu.Tutorial) {
hexPatches.Skip1.Modify();
hexPatches.Skip2.Modify();
} else {
hexPatches.Skip1.Restore();
hexPatches.Skip2.Restore();
}
/*if (Config.ExtraMenu.Ultra) {
hexPatches.Frame1.Modify();
hexPatches.Frame2.Modify();
hexPatches.Frame3.Modify();
hexPatches.Frame4.Modify();
} else {
hexPatches.Frame1.Restore();
hexPatches.Frame2.Restore();
hexPatches.Frame3.Restore();
hexPatches.Frame4.Restore();
}
if (Config.ExtraMenu.Show) {
hexPatches.Showfps1.Modify();
hexPatches.Showfps2.Modify();
} else {
hexPatches.Showfps1.Restore();
hexPatches.Showfps2.Restore();
}*/
}


auto Input_get_touchCount = (int (*) ()) (Class_Input__get_touchCount);
	 if (Input_get_touchCount() > 0) {
		auto Input_GetTouch = (Touch (*)(uintptr_t, int)) (Class_Input__GetTouch);
		auto Input_get_mousePosition = (Vector3 (*)(uintptr_t)) (Class_Input__get_mousePosition);
		switch (Input_GetTouch(Config.ImGuiMenu.thiz, 0).m_Phase) {
			case TouchPhase::Began:
			case TouchPhase::Stationary:
				io->MouseDown[0] = true;
				io->MousePos = ImVec2(Input_get_mousePosition(Config.ImGuiMenu.thiz).x, get_height() - Input_get_mousePosition(Config.ImGuiMenu.thiz).y);
				break;
			case TouchPhase::Ended:
			case TouchPhase::Canceled:
				io->MouseDown[0] = false;
				Config.ImGuiMenu.clearMousePos = true;
				break;
			case TouchPhase::Moved:
				io->MousePos = ImVec2(Input_get_mousePosition(Config.ImGuiMenu.thiz).x, get_height() - Input_get_mousePosition(Config.ImGuiMenu.thiz).y);
			break;
			default:
			break;
		}
	}
	
    ImGui::EndFrame();
    ImGui::Render();
    ImGui_ImplOpenGL3_RenderDrawData(ImGui::GetDrawData());
    return old_eglSwapBuffers(dpy, surface);
}

void* SuperThread(void*) {
    while (true) {
        auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
                if (Config.ExtraMenu.Dlq) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "10415001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1880000001", 16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "16843009", -12, Type::TYPE_DWORD);
            kFox::MemoryWrite( "1", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "5", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "400001", 52, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200032", 56, Type::TYPE_DWORD);
            kFox::MemoryWrite( "300026", 60, Type::TYPE_DWORD);
            kFox::MemorySearch( "10415001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "2066", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10582", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10415002", 8, Type::TYPE_DWORD);
            kFox::MemorySearch( "10415201", Type::TYPE_DWORD);
            kFox::MemoryOffset( "2066", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10582", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10415002", 8, Type::TYPE_DWORD);
            kFox::MemorySearch( "10415001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1057803469", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200010115", -20, Type::TYPE_DWORD);
            Dlq = true;
            kFox::ClearResult();
           }
            if (Config.ExtraMenu.Oden) {
                kFox::SetSearchRange(RegionType::ANONYMOUS);
                        kFox::MemorySearch("10125001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("1880000001", 24, Type::TYPE_DWORD);
                        kFox::MemoryWrite("16843009", -12, Type::TYPE_DWORD);
                        kFox::MemoryWrite("1", -8, Type::TYPE_DWORD);
                        kFox::MemoryWrite("5", 8, Type::TYPE_DWORD);
                        kFox::MemoryWrite("400008", 52, Type::TYPE_DWORD);
                        kFox::MemoryWrite("200132", 56, Type::TYPE_DWORD);
                        kFox::MemoryWrite("500048", 60, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10125001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("39", -16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("100287", 4, Type::TYPE_DWORD);
                        kFox::MemoryWrite("10125002", 8, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10125201", Type::TYPE_DWORD);
                        kFox::MemoryOffset("39", -16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("100287", 4, Type::TYPE_DWORD);
                        kFox::MemoryWrite("10125002", 8, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10125001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("1057803469", 16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("70111", -12, Type::TYPE_DWORD); 
               Oden = true;
            kFox::ClearResult();
           }
            if (Config.ExtraMenu.Holger) {
               kFox::SetSearchRange(RegionType::ANONYMOUS);
                        kFox::MemorySearch("10211001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("1880000001", 24, Type::TYPE_DWORD);
                        kFox::MemoryWrite("16843009", -12, Type::TYPE_DWORD);
                        kFox::MemoryWrite("1", -8, Type::TYPE_DWORD);
                        kFox::MemoryWrite("5", 8, Type::TYPE_DWORD);
                        kFox::MemoryWrite("400004", 52, Type::TYPE_DWORD);
                        kFox::MemoryWrite("200080", 56, Type::TYPE_DWORD);
                        kFox::MemoryWrite("500011", 60, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10309001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("1039", -16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("10899", 4, Type::TYPE_DWORD);
                        kFox::MemoryWrite("10211002", 8, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10211201", Type::TYPE_DWORD);
                        kFox::MemoryOffset("1039", -16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("10899", 4, Type::TYPE_DWORD);
                        kFox::MemoryWrite("10211002", 8, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10211001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("1057803469", 16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("200010444", -12, Type::TYPE_DWORD);
               Holger = true;
            kFox::ClearResult();
           }
                       if (Config.ExtraMenu.Tang) {
               kFox::SetSearchRange(RegionType::ANONYMOUS);
                        kFox::MemorySearch("10107001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("1880000001", 24, Type::TYPE_DWORD);
                        kFox::MemoryWrite("16843009", -12, Type::TYPE_DWORD);
                        kFox::MemoryWrite("1", -8, Type::TYPE_DWORD);
                        kFox::MemoryWrite("5", 8, Type::TYPE_DWORD);
                        kFox::MemoryWrite("400007", 52, Type::TYPE_DWORD);
                        kFox::MemoryWrite("200126", 56, Type::TYPE_DWORD);
                        kFox::MemoryWrite("300119", 60, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10107001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("9", -16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("100233", 4, Type::TYPE_DWORD);
                        kFox::MemoryWrite("10107146", 8, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10107001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("9", -16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("100233", 4, Type::TYPE_DWORD);
                        kFox::MemoryWrite("10107416", 8, Type::TYPE_DWORD);
     
                        kFox::MemorySearch("10107001", Type::TYPE_DWORD);
                        kFox::MemoryOffset("1057803469", 16, Type::TYPE_DWORD);
                        kFox::MemoryWrite("66737", -12, Type::TYPE_DWORD);
               Tang = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Dlq2) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "10207001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1057803469", 16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "79116", -12, Type::TYPE_DWORD);
            
            
            kFox::MemorySearch( "10207001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1035", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "100531", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10207155", 8, Type::TYPE_DWORD);
            
            kFox::MemorySearch( "10207001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1880000001", 24, Type::TYPE_DWORD);
            kFox::MemoryWrite( "16843009", -12, Type::TYPE_DWORD);
            kFox::MemoryWrite( "1", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "5", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", 32, Type::TYPE_DWORD);
            kFox::MemoryWrite( "400012", 52, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200175", 56, Type::TYPE_DWORD);
            kFox::MemoryWrite( "300168", 60, Type::TYPE_DWORD);
            Dlq2 = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Spec) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "710001101", Type::TYPE_DWORD);
            kFox::MemoryOffset( "710000042", -32, Type::TYPE_DWORD);
            kFox::MemoryOffset( "710001102", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710002569", -44, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -40, Type::TYPE_DWORD);
            kFox::MemoryWrite( "289900106", -36, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710002568", -28, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710002569", -24, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710002570", -12, Type::TYPE_DWORD);
            Spec = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Sop) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "710001101", Type::TYPE_DWORD);
            kFox::MemoryOffset( "710000042", -32, Type::TYPE_DWORD);
            kFox::MemoryOffset( "710001102", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001591", -44, Type::TYPE_DWORD);
            kFox::MemoryWrite( "310000238", -40, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -36, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001611", -28, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001591", -24, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001592", -12, Type::TYPE_DWORD);
            Sop = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Pan) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "710001101", Type::TYPE_DWORD);
            kFox::MemoryOffset( "710000042", -32, Type::TYPE_DWORD);
            kFox::MemoryOffset( "710001102", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001870", -44, Type::TYPE_DWORD);
            kFox::MemoryWrite( "289900014", -40, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -36, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001871", -28, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001870", -24, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001863", -12, Type::TYPE_DWORD);
            Pha = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Ali) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "710001101", Type::TYPE_DWORD);
            kFox::MemoryOffset( "710000042", -32, Type::TYPE_DWORD);
            kFox::MemoryOffset( "710001102", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710002334", -44, Type::TYPE_DWORD);
            kFox::MemoryWrite( "289900085", -40, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -36, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710002333", -28, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710002334", -24, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710002335", -12, Type::TYPE_DWORD);
            Ali = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Nik) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "710001101", Type::TYPE_DWORD);
            kFox::MemoryOffset( "710000042", -32, Type::TYPE_DWORD);
            kFox::MemoryOffset( "710001102", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001783", -44, Type::TYPE_DWORD);
            kFox::MemoryWrite( "289900005", -40, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -36, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001785", -28, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001783", -24, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "710001784", -12, Type::TYPE_DWORD);
            Nik = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Krm) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "10508002", Type::TYPE_DWORD);
            kFox::MemoryOffset( "10508003", -128, Type::TYPE_DWORD);
            kFox::MemoryWrite( "70247", -12, Type::TYPE_DWORD);
            
            
            kFox::MemorySearch( "10508002", Type::TYPE_DWORD);
            kFox::MemoryOffset( "28", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "300128", -36, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200135", -40, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -44, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -64, Type::TYPE_DWORD);
            kFox::MemoryWrite( "4", -88, Type::TYPE_DWORD);
            kFox::MemoryWrite( "4", -104, Type::TYPE_DWORD);
            
            kFox::MemorySearch( "10503001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "4108", -12, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10508044", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "100322", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10508044", 12, Type::TYPE_DWORD);
     
            Krm = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Dlq22) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "10207001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "10207002", -128, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200010129", -12, Type::TYPE_DWORD);
            
            
            kFox::MemorySearch( "10207001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "28", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "300022", -36, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200030", -40, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -44, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", -64, Type::TYPE_DWORD);
            kFox::MemoryWrite( "4", -88, Type::TYPE_DWORD);
            kFox::MemoryWrite( "4", -104, Type::TYPE_DWORD);
            
            kFox::MemorySearch( "10207001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1035", -12, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10207068", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10634", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10207068", 12, Type::TYPE_DWORD);
     
            Dl = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Diam) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "10207001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "28", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "490207064", -64, Type::TYPE_DWORD);
            Diam = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Ass) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "10702001", Type::TYPE_DWORD);
            kFox::MemoryWrite( "10702002", -128, Type::TYPE_DWORD);
            kFox::MemoryOffset( "73376", -12, Type::TYPE_DWORD);
            
            kFox::MemorySearch( "10702001", Type::TYPE_DWORD);
            kFox::MemoryWrite( "10", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "500032", 60, Type::TYPE_DWORD);
            kFox::MemoryWrite( "300137", 36, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200144", 40, Type::TYPE_DWORD);
            kFox::MemoryWrite( "0", 44, Type::TYPE_DWORD);
            kFox::MemoryWrite( "4", 88, Type::TYPE_DWORD);
            kFox::MemoryWrite( "4", 104, Type::TYPE_DWORD);
            
           kFox::MemorySearch( "10702001", Type::TYPE_DWORD);
           kFox::MemoryWrite( "6145", -12, Type::TYPE_DWORD);
           kFox::MemoryWrite( "10716002", 4, Type::TYPE_DWORD);
           kFox::MemoryWrite( "100405", 8, Type::TYPE_DWORD);
           kFox::MemoryWrite( "10716002", 12, Type::TYPE_DWORD);
            Ass = true;
            kFox::ClearResult();
           }
           if (Config.ExtraMenu.Cb) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "10420001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1880000001", 24, Type::TYPE_DWORD);
            kFox::MemoryWrite( "16843009", -12, Type::TYPE_DWORD);
            kFox::MemoryWrite( "1", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "5", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "400005", 52, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200102", 56, Type::TYPE_DWORD);
            kFox::MemoryWrite( "500032", 60, Type::TYPE_DWORD);
            kFox::MemorySearch( "10420001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "2073", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "100082", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10420002", 8, Type::TYPE_DWORD);
     
            kFox::MemorySearch( "10420201", Type::TYPE_DWORD);
            kFox::MemoryOffset( "2073", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "100082", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10420002", 8, Type::TYPE_DWORD);
            
            kFox::MemorySearch( "10420001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1057803469", 16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "7778", -12, Type::TYPE_DWORD);
            Cb = true;
            kFox::ClearResult();
          }
          if (Config.ExtraMenu.Kol) {
            kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "10124001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1880000001", 24, Type::TYPE_DWORD);
            kFox::MemoryWrite( "16843009", -12, Type::TYPE_DWORD);
            kFox::MemoryWrite( "1", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "5", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite( "400006", 52, Type::TYPE_DWORD);
            kFox::MemoryWrite( "200112", 56, Type::TYPE_DWORD);
            kFox::MemoryWrite( "300105", 60, Type::TYPE_DWORD);
            
            kFox::MemorySearch( "10124001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "38", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "100155", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10125002", 8, Type::TYPE_DWORD);
            
            kFox::MemorySearch( "10125201", Type::TYPE_DWORD);
            kFox::MemoryOffset( "39", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "100287", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite( "10125002", 8, Type::TYPE_DWORD);
            
            kFox::MemorySearch( "10124001", Type::TYPE_DWORD);
            kFox::MemoryOffset( "1057803469", 16, Type::TYPE_DWORD);
            kFox::MemoryWrite( "9479", -12, Type::TYPE_DWORD);
            Kol = true;
            kFox::ClearResult();
        }
        if (Config.ExtraMenu.Mol) {
            kFox::MemorySearch("10424001", Type::TYPE_DWORD);
            kFox::MemoryOffset("1880000001", 24, Type::TYPE_DWORD);
            kFox::MemoryWrite("16843009", -12, Type::TYPE_DWORD);
            kFox::MemoryWrite("1", -8, Type::TYPE_DWORD);
            kFox::MemoryWrite("5", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite("0", 32, Type::TYPE_DWORD);
            kFox::MemoryWrite("400009", 52, Type::TYPE_DWORD);
            kFox::MemoryWrite("200143", 56, Type::TYPE_DWORD);
            kFox::MemoryWrite("500058", 60, Type::TYPE_DWORD);     
            
            kFox::MemoryWrite("2", 64, Type::TYPE_DWORD);
            
            kFox::MemorySearch("10424001", Type::TYPE_DWORD);
            kFox::MemoryOffset("2077", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite("100350", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite("10424002", 8, Type::TYPE_DWORD);
            
            kFox::MemorySearch("10424201", Type::TYPE_DWORD);
            kFox::MemoryOffset("2077", -16, Type::TYPE_DWORD);
            kFox::MemoryWrite("100350", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite("10424002", 8, Type::TYPE_DWORD);
            
            kFox::MemorySearch("10424001", Type::TYPE_DWORD);
            kFox::MemoryOffset("1057803469", 16, Type::TYPE_DWORD);
            kFox::MemoryWrite("72358", -12, Type::TYPE_DWORD);
            
            kFox::MemorySearch("361002548", Type::TYPE_DWORD);
            kFox::MemoryOffset("361002549", 4, Type::TYPE_DWORD);
            kFox::MemoryOffset("300000005", 16, Type::TYPE_DWORD);
            kFox::MemoryOffset("300000047", 20, Type::TYPE_DWORD);
            kFox::MemoryOffset("361002550", 44, Type::TYPE_DWORD);
            kFox::MemoryOffset("361002549", 48, Type::TYPE_DWORD);
            kFox::MemoryOffset("361002551", 76, Type::TYPE_DWORD);
            kFox::MemoryOffset("361002552", 80, Type::TYPE_DWORD);
            
            kFox::MemoryWrite("361002562", 0, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002563", 4, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002573", 8, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002658", 12, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002572", 16, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002574", 20, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002575", 28, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002564", 44, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002563", 48, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002579", 52, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002551", 76, Type::TYPE_DWORD);
            kFox::MemoryWrite("361002552", 80, Type::TYPE_DWORD);
            Kol = true;
            kFox::ClearResult();
        }
             
            if (Config.ExtraMenu.Hid) {
                 kFox::SetSearchRange(RegionType::ANONYMOUS);
            kFox::MemorySearch( "0.1439999938", Type::TYPE_FLOAT);
            kFox::MemoryWrite( "3", 0, Type::TYPE_FLOAT);
            
            kFox::ClearResult();
            He1 = true;
       
            }
        
       
            
        auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
        std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
    }
    return nullptr;
}

bool (*orig_RadarMap)(void *instance);
bool getRadarMap(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Outline) {
             return true;
        }
    }
    return orig_RadarMap(instance);
}

bool (*orig_framerate)(void *instance);
bool getframerate(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Framerate) {
             return true;
        }
    }
    return orig_framerate(instance);
}

/*float (*old_Xshoter6)(void *instance);
float Xshoter6(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Scope) {
           return 0.0000001;
        }
    }
    return old_Xshoter6(instance);
}

float (*orig_switch)(void *instance);
float getSwitch(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Switch) {
           return 0.0000001;
        }
    }
    return orig_switch(instance);
}*/

float (*orig_PlayerControllerGetRotateSpeed)(void *instance, float assistDis, float dis, float angle, float rotateTime, bool gamepadInput);
float _PlayerControllerGetRotateSpeed(void *instance, float assistDis, float dis, float angle, float rotateTime, bool gamepadInput) {
    if (instance != NULL) {
    
        if (Config.ExtraMenu.AimAssist) {
        
            return (float) Config.ExtraMenu.SizeAim;
        }
    }
    return orig_PlayerControllerGetRotateSpeed(instance, assistDis, dis, angle, rotateTime, gamepadInput);
}

float (*orig_PlayerControllerGetAssitAimSpeed)(void *instance, Vector3 assistCentorPos, float assistDis, float dis, float angle, bool isPVE, bool gamepadInput);
float _PlayerControllerGetAssitAimSpeed(void *instance, Vector3 assistCentorPos, float assistDis, float dis, float angle, bool isPVE, bool gamepadInput) {
    if (instance != NULL) {
    
        if (Config.ExtraMenu.AimAssist) {
        
            return (float) Config.ExtraMenu.SizeAim;
}
}
    return orig_PlayerControllerGetAssitAimSpeed(instance, assistCentorPos, assistDis, dis, angle, isPVE, gamepadInput);
}

float (*orig_GetAssistAimRotateTime)(void *instance, float dis, bool gamepadInput);
float _GetAssistAimRotateTime(void *instance, float dis, bool gamepadInput) {
    if (instance != NULL) {
        if (Config.ExtraMenu.AimAssist2) {
            return (float) Config.ExtraMenu.SizeAim2;
            *(float *) ((uintptr_t) instance + 0x1B61E34) = Config.ExtraMenu.SizeAim2;
        }
    }
    return orig_GetAssistAimRotateTime(instance, dis, gamepadInput);
}

float (*orig_GetAutoAssistAimRate)(void *instance, float dist, float toQuasiDist, bool isMPPVE, float aimAngle, bool gamepadInput);
float _GetAutoAssistAimRate(void *instance, float dist, float toQuasiDist, bool isMPPVE, float aimAngle, bool gamepadInput) {
    if (instance != NULL) {
        if (Config.ExtraMenu.AimAssist2) {
            return (float) Config.ExtraMenu.SizeAim2;
            *(float *) ((uintptr_t) instance + 0x1B622FC) = Config.ExtraMenu.SizeAim2;
        }
    }
    return orig_GetAutoAssistAimRate(instance, dist, toQuasiDist, isMPPVE, aimAngle, gamepadInput);
}

float (*old_Xshoter1)(void *instance);
float Xshoter1(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Recoil) {
           return 0.0000001;
        }
    }
    return old_Xshoter1(instance);
}

float (*orig_Reload)(void *instance);
float getReload(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Reload) {
            return 0.000001;
        }
    }
    return orig_Reload(instance);
}

float (*orig_ShotSpread)(void *instance);
float getShotSpread(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Spread) {
           return 0.0000001;
        }
    }
    return orig_ShotSpread(instance);
}

float (*old_Xshoter6)(void *instance);
float Xshoter6(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Scope) {
           return 0.01;
        }
    }
    return old_Xshoter6(instance);
}

float (*orig_switch)(void *instance);
float getSwitch(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Switch) {
           return 0.0000001;
        }
    }
    return orig_switch(instance);
}

bool (*old_SingleLineCheckPhysics)(void *instance, int hitType, void *hitTarget, void *hitCollider, Vector3 startPos, Vector3 dir, void *impactInfo);
bool SingleLineCheckPhysics(void *instance, int hitType, void *hitTarget, void *hitCollider, Vector3 startPos, Vector3 dir, void *impactInfo) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Buff) {      
           return true;
        }      
    }
    return old_SingleLineCheckPhysics(instance, hitType, hitTarget, hitCollider, startPos, dir, impactInfo);
}

float (*orig_overheat)(void *instance);
float getOverHeat(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Heat) {
           return 0.0000001;
        }      
    }
    return orig_overheat(instance);
}

float (*orig_fastswim)(void *instance);
float getFastSwim(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Swim) {
           return 0.0000001;
        }      
    }
    return orig_fastswim(instance);
}

float (*orig_br)(void *instance);
float getbr(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Parachute) {
           return 0.0000001;
        }      
    }
    return orig_br(instance);
}

/*float (*old_IsAimTargetCanAutoFire)(void *instance);
float IsAimTargetCanAutoFire(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Fire) {
           return 0.0000001;
        }      
    }
    return old_IsAimTargetCanAutoFire(instance);
}

float (*old_GetFireValue)(void *instance);
float GetFireValue(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Rate) {
           return 0.0000001;
        }      
    }
    return old_GetFireValue(instance);
}*/

float (*orig_Zgcross7)(void *instance);
float Zgcross7(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Smallcross) {
            return 0;
        }
    }
    return orig_Zgcross7(instance);
}

bool (*orig_AdvanceUAV)(void *instance);
bool getAdvanceUAV(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Uav) {
             return true;
        }
    }
    return orig_AdvanceUAV(instance);
}

float (*old_Xshoter9)(void *instance);
float Xshoter9(void *instance) {
    if (instance != NULL) {
        if (Config.ExtraMenu.Slide) {
           return Config.ExtraMenu.SizeSlide;
        }
     }
    return old_Xshoter9(instance);
}

float (*orig_jumper)(void *instance);
float getJumper(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Jump) {
           return Config.ExtraMenu.SizeJump;
        }
    }
    return orig_jumper(instance);
}

float (*orig_Zgspeed14)(void *instance);
float Zgspeed14(void *instance) {
    if (instance != NULL) {
      if (Config.ExtraMenu.Speed) {      
           return Config.ExtraMenu.SizeSpeed;
        }      
    }
    return orig_Zgspeed14(instance);
}

//Function pointer defination and Function Hook defination are given below

int (*osub_E20C2)(const char* a1, unsigned int a2);// Function pointer definition
int hsub_E20C2(const char* a1, unsigned int a2)// Hook function definition
{
    while (true)
    {
        sleep(10000); // Sleep for 10000 milliseconds: Fixed 90% crash for good hooks
    }
    return osub_E20C2(a1, a2);
}









// ADD YOUR HOOKS BELOW

//Run your hooks inside the below threads, For your understanding purpose, i have use example calls 


//Call unity hooks here
void * cyber_thread(void *) {
    LOGI(OBFUSCATE("ANTIBAN"));

     do {
        sleep(1);
    } while (!isLibraryLoaded("libunity.so"));
    
    LOGI(OBFUSCATE("%s has been loaded\n"), (const char *) Libunity);
    
	

	return NULL;
}

//Call anort hooks here
void * cyber1_thread(void *) {
       LOGI(OBFUSCATE("CYBER LIBRARY IS READY....\n")); //Don't change this part, else you dont get LOGS
	   
     do {
        sleep(1);
    } while (!isLibraryLoaded("libanort.so"));
    LOGI(OBFUSCATE("%s has been loaded\n"), (const char *) Libanort); //anort hook func call example 
   
	/*HOOK_LIB("libanort.so", "0xE20C3", hsub_E20C2, osub_E20C2);*/
	
	//PATCH_LIB("libanort.so", "0x36E70", "00 00 A0 E3 1E FF 2F E1");
    //PATCH_LIB("libanort.so", "0x36E78", "00 00 A0 E3 1E FF 2F E1");
	
    return NULL;
}

//Call anogs hooks here
void * cyber2_thread(void *) {
    LOGI(OBFUSCATE("ANTIBAN"));

     do {
        sleep(1);
    } while (!isLibraryLoaded("libanogs.so"));
    LOGI(OBFUSCATE("%s has been loaded\n"), (const char *) Libanogs);


/*PATCH_LIB("libanogs.so", "0x2783AC", "00 00 A0 E3");
PATCH_LIB("libanogs.so", "0x33BA04", "00 20 70 47");
PATCH_LIB("libanogs.so", "0x2C733C", "1E FF 2F E1");
PATCH_LIB("libanogs.so", "0x3331B8", "00 00 A0 E3");
PATCH_LIB("libanogs.so", "0x170E8", "00 20 70 47");
PATCH_LIB("libanogs.so", "0x4E48", "00 20 70 47");
PATCH_LIB("libanogs.so", "0x335EAC", "00 00 A0 E3");
PATCH_LIB("libanogs.so", "0x335F94", "65 00 6E 00");
PATCH_LIB("libanogs.so", "0x170E8", "65 6C 74 00");
PATCH_LIB("libanogs.so", "0x57991", "70 6F 74 00");
PATCH_LIB("libanogs.so", "0x3374E0", "44 61 74 00");
PATCH_LIB("libanogs.so", "0x44168", "00 00 00 17");
PATCH_LIB("libanogs.so", "0x226C", "E8 BD B0 02");
PATCH_LIB("libanogs.so", "0x22A4", "E8 BD B0 02");
PATCH_LIB("libanogs.so", "0x50D63", "E8 BD 0B 00");
PATCH_LIB("libanogs.so", "0x79D48", "F0 00 28 00");
PATCH_LIB("libanogs.so", "0x87F8", "F2 42 90 05");
PATCH_LIB("libanogs.so", "0xCBF8", "F4 4F 46 21");
PATCH_LIB("libanogs.so", "0xDE70", "F2 1D 62 DC");
PATCH_LIB("libanogs.so", "0x33BA0C", "F0 08 F8 56");
PATCH_LIB("libanogs.so", "0x33BA50", "F2 1D A8 01");
PATCH_LIB("libanogs.so", "0x33B9F4", "F1 08 46 81");*/
//PATCH_LIB("libanogs.so", "0x27A94E", "00 20 70 47");
//PATCH_LIB("libanogs.so", "0x276488", "00 20 70 47");

//PATCH_LIB("libanogs.so", "0x499B0", "00 20 70 47");
//PATCH_LIB("libanogs.so", "0x8E13C", "00 20 70 47");
//PATCH_LIB("libanogs.so", "0x46BAC", "00 00 A0 E3 1E FF 2F E1");
//PATCH_LIB("libanogs.so", "0x46BB4", "00 00 A0 E3 1E FF 2F E1");

/*
0x27f7
0x2f02
PATCH_LIB("libanogs.so", "0xB08CC", "1E FF 2F E1");
PATCH_LIB("libanogs.so", "0x10CC", "00 00 A0 E3");
PATCH_LIB("libanogs.so", "0x10D0", "65 00 6E 00");
PATCH_LIB("libanogs.so", "0x10D4", "65 6C 74 00");
PATCH_LIB("libanogs.so", "0x10D8", "70 6F 74 00");
PATCH_LIB("libanogs.so", "0x10DC", "44 61 74 00");
PATCH_LIB("libanogs.so", "0x718A8", "1E FF 2F E1");
PATCH_LIB("libanogs.so", "0x240F8", "00 00 00 17");
PATCH_LIB("libanogs.so", "0x4AF34", "E8 BD B0 02");
PATCH_LIB("libanogs.so", "0x4AF44", "E8 BD B0 02");
PATCH_LIB("libanogs.so", "0x4AF48", "E8 BD 0B 00");
PATCH_LIB("libanogs.so", "0x4AFA8", "F0 00 28 00");
PATCH_LIB("libanogs.so", "0x5A1F0", "F2 42 90 05");
PATCH_LIB("libanogs.so", "0x5A244", "F4 4F 46 21");
PATCH_LIB("libanogs.so", "0x5A248", "F2 1D 62 DC");
PATCH_LIB("libanogs.so", "0x5A284", "F0 08 F8 56");
PATCH_LIB("libanogs.so", "0x5A31C", "F2 1D A8 01");
PATCH_LIB("libanogs.so", "0x5A438", "F1 08 46 81");*/

	return NULL;
}

//Call gcloud hooks here
void * cyber3_thread(void *) {
    LOGI(OBFUSCATE("ANTIBAN"));

     do {
        sleep(1);
    } while (!isLibraryLoaded("libgcloud.so"));
    LOGI(OBFUSCATE("%s has been loaded\n"), (const char *) Libgcloud);
   
	
	return NULL;
}

//Call tdata hooks here
void * cyber4_thread(void *) {
    LOGI(OBFUSCATE("ANTIBAN"));

     do {
        sleep(1);
    } while (!isLibraryLoaded("libTDataMaster.so"));
    LOGI(OBFUSCATE("%s has been loaded\n"), (const char *) Libtdata);
   
	
	return NULL;
}

//Call crashsight hooks here
void * cyber5_thread(void *) {
    LOGI(OBFUSCATE("ANTIBAN"));

     do {
        sleep(1);
    } while (!isLibraryLoaded("libCrashSight.so"));
    LOGI(OBFUSCATE("%s has been loaded\n"), (const char *) Libcrashsight);
   
	
	return NULL;
}


void *Init_Thread2() {
    
     do {
        sleep(1);
    } while (!isLibraryLoaded("libil2cpp.so")|!isLibraryLoaded("libunity.so")|!isLibraryLoaded("libanogs.so")|!isLibraryLoaded("libTDataMaster.so")|!isLibraryLoaded("libanort.so")|!isLibraryLoaded("libgcloud.so")|!isLibraryLoaded("libgcloudcore.so"));
        address = findLibrary("libil2cpp.so");
        address = findLibrary("libunity.so");
        address = findLibrary("libanogs.so");
        address = findLibrary("libgcloud.so");
        address = findLibrary("libgcloudcore.so");
        address = findLibrary("libTDataMaster.so");
        address = findLibrary("libanort.so");
		
//=====================================================================\\
//============================ MISC OFFSETS ============================\\
//=====================================================================\\
//BYPASS AUTO LOGO
MemoryPatch::createWithHex("libanogs.so", 0x3AA8C, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3B2C0, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3B650, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3BA30, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3BDB0, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3C53C, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3D86C, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3DA98, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3E3FC, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3E778, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3F3C0, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3F800, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x3F950, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x430C0, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x439CC, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x44F88, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x46460, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x8F0DC, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x8F0E0, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0xBA724, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0xBA728, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0xF36A8, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0xF36AC, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0xF531C, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0xF5320, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x105494, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x105498, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x14ED2C, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x14ED30, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x15B8B4, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x15B8B8, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x179430, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x179434, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x17A1A8, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x17A1AC, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x192A18, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x192A1C, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x192B88, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x192B8C, "1E FF 2F E1").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x338FD8, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x338FD4, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x338FD0, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x338FC8, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanort.so", 0x369C8, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanort.so", 0x369D8, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanort.so", 0x369E0, "50 47 00 FF").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x10D74, "1E FF 2F E").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x10D48, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x33902C, "1E FF 2F E").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x339028, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x339024, "1E FF 2F E").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x338FEC, "00 00 A0 E3").Modify();
MemoryPatch::createWithHex("libanogs.so", 0x338FE8, "1E FF 2F E").Modify();

//BYPASS LOBBY
hexPatches.Lobby1 = MemoryPatch::createWithHex("libanogs.so", 0x3AA8C, "00 47 FF 00");
hexPatches.Lobby2 = MemoryPatch::createWithHex("libanogs.so", 0x3B2C0, "00 47 FF 00");
hexPatches.Lobby3 = MemoryPatch::createWithHex("libanogs.so", 0x3B650, "00 47 FF 00");
hexPatches.Lobby4 = MemoryPatch::createWithHex("libanogs.so", 0x3BA30, "00 47 FF 00");
hexPatches.Lobby5 = MemoryPatch::createWithHex("libanogs.so", 0x3BDB0, "00 47 FF 00");
hexPatches.Lobby6 = MemoryPatch::createWithHex("libanogs.so", 0x3C53C, "00 47 FF 00");
hexPatches.Lobby7 = MemoryPatch::createWithHex("libanogs.so", 0x3D86C, "A0 47 FF 00");
hexPatches.Lobby8 = MemoryPatch::createWithHex("libanogs.so", 0x3DA98, "00 47 FF 00");
hexPatches.Lobby9 = MemoryPatch::createWithHex("libanogs.so", 0x3E3FC, "00 47 FF 00");
hexPatches.Lobby10 = MemoryPatch::createWithHex("libanogs.so", 0x3E778, "00 47 FF 00");
hexPatches.Lobby11 = MemoryPatch::createWithHex("libanogs.so", 0x3F3C0, "00 47 FF 00");

//Wallhack
hexPatches.Norwall = MemoryPatch::createWithHex("libil2cpp.so",0x16B66D0,"00 00 00 00");

//AUTO SKIP TUTORIAL ( GR ONLY )
/*sleep(5);
MemoryPatch::createWithHex("libil2cpp.so", 0x4d0d13c, "01 00 A0 E3").Modify();
MemoryPatch::createWithHex("libil2cpp.so", 0x4d0d140, "1E FF 2F E1").Modify();*/

//Medium Aim DONE
hexPatches.Mediumaim1 = MemoryPatch::createWithHex("libil2cpp.so",0x22A4DE8,"33 01 44 E3");
hexPatches.Mediumaim2 = MemoryPatch::createWithHex("libil2cpp.so",0x22A4DEC,"1E FF 2F E1");
 
//Dark Mode
hexPatches.Dark1 = MemoryPatch::createWithHex("libunity.so",0x1595b4, "00 00 27 41");
hexPatches.Dark2 = MemoryPatch::createWithHex("libunity.so",0x1617d4, "00 00 00 00");

//No FlashBang
hexPatches.Flashbang = MemoryPatch::createWithHex("libil2cpp.so",0x1A76090, "1E FF 2F E1");


    return 0;
}

void Init_Thread() {
    while (!m_Il2Cpp) {
        m_Il2Cpp = Tools::GetBaseAddress(m_IL2CPPLIB);
		sleep(1);
		
}    
    LOGI("libil2cpp.so: %p", m_Il2Cpp);

    Il2CppAttach();
    sleep(5);
    std::thread(Main_Thread).detach();
	
	  //Wallhack Outline
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("EffectInstance_SeeFront"), OBFUSCATE("IsEffectActive")), (void *) getRadarMap, (void **) &orig_RadarMap); 
	  Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("EffectInstance_SeeFrontGlow"), OBFUSCATE("IsEffectActive")), (void *) getRadarMap, (void **) &orig_RadarMap);
	
	  //No Recoil
	  Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameEngine"),OBFUSCATE("WeaponFireComponent_Instant") , OBFUSCATE("GetScaleRecoil")), (void *)  &Xshoter1, (void **) &old_Xshoter1);
	  
	  //No Reload   
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("WeaponFireComponent"), OBFUSCATE("get_ChangeClipTime")), (void *) getReload, (void **) &orig_Reload);
	  
	  //Less Spread
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameEngine"),OBFUSCATE("WeaponFireComponent_Instant") , OBFUSCATE("MinInaccuracy")), (void *)  getShotSpread, (void **) &orig_ShotSpread);
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameEngine"),OBFUSCATE("WeaponFireComponent_Instant") , OBFUSCATE("MaxInaccuracy")), (void *)  getShotSpread, (void **) &orig_ShotSpread);
	  
	  //Fast Scope
	  Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameBase"),OBFUSCATE("Weapon") , OBFUSCATE("get_AimingTime")), (void *)  &Xshoter6, (void **) &old_Xshoter6);
	  
	  //Fast Switch
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameBase"),OBFUSCATE("Weapon") , OBFUSCATE("get_EquipTime")), (void *)  &getSwitch, (void **) &orig_switch); 
	  
	  //Fast Scope
	  Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameBase"),OBFUSCATE("Weapon") , OBFUSCATE("get_AimingTime")), (void *)  &Xshoter6, (void **) &old_Xshoter6);
	  // Fast Switch
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameBase"),OBFUSCATE("Weapon") , OBFUSCATE("get_EquipTime")), (void *)  &getSwitch, (void **) &orig_switch); 
	  
	  //No overheat RPD
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameEngine"),OBFUSCATE("WeaponFireComponent") , OBFUSCATE("get_AddHotTime")), (void *)  getOverHeat, (void **) &orig_overheat);
	  
	  //Small crosshair
      Tools::Hook((void *) (uintptr_t) Il2CppGetMethodOffset("Assembly-CSharp.dll", "GameEngine","WeaponFireComponent_Instant","get_CrossHairSizeBase"), (void *) Zgcross7, (void **) &orig_Zgcross7);
	  
	  //Advance UAV1
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("GameInfo"), OBFUSCATE("get_AdvanceUAVEnabled")), (void *) getAdvanceUAV, (void **) &orig_AdvanceUAV);
	  
      //Long Slide
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","GameBase","SlideTackleComponent" , "get_SlideTackleSpeed"), (void *) &Xshoter9, (void **) &old_Xshoter9);
	  
	  //Speed hack
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset("Assembly-CSharp.dll","GameEngine","PlayerInfo" , "get_MoveSpeedScale"), (void *) Zgspeed14, (void **) &orig_Zgspeed14);
	  
	  //High Jump
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameBase"),OBFUSCATE("Pawn"), OBFUSCATE("get_MaxJumpHeightScale")), (void *) &getJumper, (void **) &orig_jumper);
	  
	  //Framerate
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("SystemSetting"), OBFUSCATE("GetMaxSupportedFrameRateLevelInternal"), 0), (void *) &getframerate, (void **) &orig_framerate);
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("SystemSetting"), OBFUSCATE("GetMaxSupportedFrameRateLevelForDevice"), 0), (void *) &getframerate, (void **) &orig_framerate);
	
	  //Aim Assist  
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("PlayerController"), OBFUSCATE("GetRotateSpeed"), 5), (void *) _PlayerControllerGetRotateSpeed, (void **) &orig_PlayerControllerGetRotateSpeed);
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("PlayerController"), OBFUSCATE("GetAssitAimSpeed"), 6), (void *) _PlayerControllerGetAssitAimSpeed, (void **) &orig_PlayerControllerGetAssitAimSpeed);
	  
      //Aim Assist Sniper
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Weapon"), OBFUSCATE("GetAssistAimRotateTime"), 2), (void *) _GetAssistAimRotateTime, (void **) &orig_GetAssistAimRotateTime);
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Weapon"), OBFUSCATE("GetAutoAssistAimRate"), 5), (void *) _GetAutoAssistAimRate, (void **) &orig_GetAutoAssistAimRate);
	  
	  
	  //added
      // Auto Fire
      /*Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameEngine"),OBFUSCATE("PlayerController") , OBFUSCATE("IsAimTargetCanAutoFire"), 1), (void *)  &IsAimTargetCanAutoFire, (void **) &old_IsAimTargetCanAutoFire);
*/
	  // Fast Swim
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameBase"),OBFUSCATE("PlayerPawn") , OBFUSCATE("CalcSwimmingSpeedScale")), (void *)  &getFastSwim, (void **) &orig_fastswim);  
	  
	  //Buff Damage
	  Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"),OBFUSCATE("GameEngine"),OBFUSCATE("WeaponFireComponent_Instant") , OBFUSCATE("SingleLineCheckPhysics"), 6), (void *)  &SingleLineCheckPhysics, (void **) &old_SingleLineCheckPhysics);
	  
      //No Parachute
      Tools::Hook((void *) (uintptr_t)Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("SkydivingPhysics"), OBFUSCATE("OpenParachute"), 1), (void *) &getbr, (void **) &orig_br);
	  
      //Bullet Track 360
      Tools::Hook(Il2CppGetMethodOffset("Assembly-CSharp.dll", "GameEngine", "WeaponFireComponent_Instant", "CreateBulletLine", 3), (void *)WeaponFireComponent_Instant_CreateBulletLine, (void **)&oWeaponFireComponent_Instant_CreateBulletLine);
      Tools::Hook(Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("WeaponFireComponent_Instant"), OBFUSCATE("CreateBulletProjectile"), 7), (void *)WeaponFireComponent_Instant_CreateBulletProjectile, (void **)&oWeaponFireComponent_Instant_CreateBulletProjectile);
	  
	  Tools::Hook((void *) dlsym(RTLD_NEXT, "eglSwapBuffers"), (void *) hook_eglSwapBuffers, (void **) &old_eglSwapBuffers);
}

JNIEXPORT jint JNICALL JNI_OnLoad(JavaVM *vm, void *reserved) {
    VM = vm;
    return JNI_VERSION_1_6;
}

__attribute__((constructor))
void lib_main() {
	pthread_t ptid;
    pthread_create(&ptid, NULL, cyber_thread, NULL);
    pthread_create(&ptid, NULL, cyber1_thread, NULL);
    pthread_create(&ptid, NULL, cyber2_thread, NULL);
	pthread_create(&ptid, NULL, cyber3_thread, NULL);
	pthread_create(&ptid, NULL, cyber4_thread, NULL);
	pthread_create(&ptid, NULL, cyber5_thread, NULL);
    pthread_t t;
	pthread_create(&t, 0, SuperThread, 0);
	std::thread(Init_Thread2).detach();
	std::thread(Init_Thread).detach();
}
