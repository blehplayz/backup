#pragma once

#define m_IL2CPPLIB OBFUSCATE("libil2cpp.so")

#define SLEEP_TIME 1000LL / 60LL

//Class Input -> UnityEngine.dll
#define Class_Input__get_touchCount (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"), OBFUSCATE("get_touchCount"))
#define Class_Input__GetTouch (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"), OBFUSCATE("GetTouch"), 1)
#define Class_Input__get_mousePosition (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Input"), OBFUSCATE("get_mousePosition"))

//Class Screen -> UnityEngine.dll
#define Class_Screen__get_width (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Screen"), OBFUSCATE("get_width"))
#define Class_Screen__get_height (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Screen"), OBFUSCATE("get_height"))
#define Class_Screen__get_density (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Screen"), OBFUSCATE("get_dpi"))
 
//Class Camera -> UnityEngine.dll
#define Class_Camera__get_main (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"), OBFUSCATE("get_main"))
#define Class_Camera__WorldToScreenPoint (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Camera"), OBFUSCATE("WorldToScreenPoint"), 1)

#define Class_Component__get_transform (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Component"), OBFUSCATE("get_transform"))
#define Class_Transform__get_position (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("UnityEngine.dll"), OBFUSCATE("UnityEngine"), OBFUSCATE("Transform"), OBFUSCATE("get_position"))

#define Class_Gameplay__get_MatchGame (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("GamePlay"), OBFUSCATE("get_MatchGame"))
#define Class_Gameplay__get_LocalPawn (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("GamePlay"), OBFUSCATE("get_LocalPawn"))
#define Class_Pawn_get_IsFiring (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Pawn"), OBFUSCATE("get_IsFiring"))

#define Class_Pawn_set_AimRotation (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Pawn"), OBFUSCATE("set_AimRotation"), 1)
#define Class_Pawn_IsAiming (uintptr_t) Il2CppGetMethodOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Pawn"), OBFUSCATE("IsAiming"))
#define Pawn_m_IsAlive  Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Pawn"), OBFUSCATE("m_IsAlive"))
    
#define Class_Pawn__m_Mesh Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Pawn"), OBFUSCATE("m_Mesh"))
#define Class_Pawn__m_HeadBone Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Pawn"), OBFUSCATE("m_HeadBone"))
#define Class_Pawn__m_PlayerInfo Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Pawn"), OBFUSCATE("m_PlayerInfo"))
#define Class_Pawn__m_IsBot Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("Pawn"), OBFUSCATE("m_IsBot"))

#define Class_BaseGame__EnemyPawns Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameBase"), OBFUSCATE("BaseGame"), OBFUSCATE("EnemyPawns"))
#define Class_PlayerInfo__m_NickName Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("PlayerInfo"), OBFUSCATE("m_NickName"))

#define Class_AttackableTarget__m_AttackableInfo Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("AttackableTarget"), OBFUSCATE("m_AttackableInfo"))
#define Class_AttackableTarget__m_Health Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("AttackableTargetInfo"), OBFUSCATE("m_Health"))
#define Class_AttackableTarget__m_MaxHealth Il2CppGetFieldOffset(OBFUSCATE("Assembly-CSharp.dll"), OBFUSCATE("GameEngine"), OBFUSCATE("AttackableTargetInfo"), OBFUSCATE("m_MaxHealth"))

