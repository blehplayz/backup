#pragma once

class Camera {
	public:
	static Camera *get_main() {
		return reinterpret_cast<Camera *(__fastcall *)()>(Class_Camera__get_main)();
	}
};

Vector3 WorldToScreenPoint(Vector3 position) {
	return reinterpret_cast<Vector3 (__fastcall *)(Camera *, Vector3)>(Class_Camera__WorldToScreenPoint)(Camera::get_main(), position);
}


class Transform {
	public:
	Vector3 get_position() {
		return reinterpret_cast<Vector3(__fastcall *)(Transform *)>(Class_Transform__get_position)(this);
	}
	
};


class Component {
	public:
	Transform *get_transform() {
		return reinterpret_cast<Transform *(__fastcall *)(Component *)>(Class_Component__get_transform)(this);
	}
	
};

int get_width() {
	return reinterpret_cast<int(__fastcall *)()>(Class_Screen__get_width)();
}

int get_height() {
	return reinterpret_cast<int(__fastcall *)()>(Class_Screen__get_height)();
}

float get_density() {
	return reinterpret_cast<float(__fastcall *)()>(Class_Screen__get_density)();
}
