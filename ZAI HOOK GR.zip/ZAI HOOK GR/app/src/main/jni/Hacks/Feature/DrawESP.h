#pragma clang diagnostic push
#pragma ide diagnostic ignored "OCDFAInspection"
#pragma once

static ESP *m_Canvas = 0;
#include <malloc.h>
#include <errno.h>
#include <stdarg.h>

char extra[30];
int atas, kanan;

int32_t ToColor(float *col) {
    return ImGui::ColorConvertFloat4ToU32(*(ImVec4 *) (col));
}
int botCount, playerCount;
bool isEspReady;
uintptr_t GetClosestTarget() {
    uintptr_t result = 0;

    float MaxDist = std::numeric_limits<float>::infinity();

        auto Gameplay_get_MatchGame = (uintptr_t (*)()) (Class_Gameplay__get_MatchGame);
        auto get_MatchGame = Gameplay_get_MatchGame();
        if (Tools::IsPtrValid((void *) get_MatchGame)) {
            auto Gameplay_get_LocalPawn = (uintptr_t (*)()) (Class_Gameplay__get_LocalPawn);
            auto LocalPawn = Gameplay_get_LocalPawn();
            if (LocalPawn) {
                Vector3 MyPos{0, 0, 0};

                auto local_m_Mesh = *(Transform **) (LocalPawn + Class_Pawn__m_Mesh);
                if (local_m_Mesh) {
                    MyPos = local_m_Mesh->get_position();
                }

                    auto EnemyPawns = *(List<uintptr_t> **) (get_MatchGame + Class_BaseGame__EnemyPawns);
                if (EnemyPawns) {
                    auto Items = EnemyPawns->getItems();
                    if (Items) {
                        for (int i = 0; i < EnemyPawns->getSize(); i++) {
                            auto Pawn = Items[i];
                            if (Pawn) {
                                if (!*(bool *) (Pawn + Pawn_m_IsAlive))
                                    continue;

                                    auto m_Mesh = *(Transform **) (Pawn + Class_Pawn__m_Mesh);
                                if (!m_Mesh)
                                    continue;

                                auto RootPos = m_Mesh->get_position();
                                float Distance = Vector3::Distance(MyPos, RootPos);

                                if (Distance < MaxDist) {
                                    result = Pawn;
                                    MaxDist = Distance;
                                }
                            }
                        }
                    }
                }
            }
        }
    return result;
}
bool isInsideFOV(int x, int y) {
    if (!Config.Aim.Size)
        return true;

    int circle_x = get_width() / 2;
    int circle_y = get_height() / 2;
    int rad = Config.Aim.Size;
    return (x - circle_x) * (x - circle_x) + (y - circle_y) * (y - circle_y) <= rad * rad;
}

uintptr_t GetInsideFOVTarget() {
    uintptr_t result = 0;

    float MaxDist = std::numeric_limits<float>::infinity();

        auto Gameplay_get_MatchGame = (uintptr_t (*)()) (Class_Gameplay__get_MatchGame);
        auto get_MatchGame = Gameplay_get_MatchGame();
        if (Tools::IsPtrValid((void *) get_MatchGame)) {
            auto Gameplay_get_LocalPawn = (uintptr_t (*)()) (Class_Gameplay__get_LocalPawn);
            auto LocalPawn = Gameplay_get_LocalPawn();
            if (LocalPawn) {
                Vector3 MyPos{0, 0, 0};

                auto local_m_Mesh = *(Transform **) (LocalPawn + Class_Pawn__m_Mesh);
                if (local_m_Mesh) {
                    MyPos = local_m_Mesh->get_position();
                }

                auto EnemyPawns = *(List<uintptr_t> **) (get_MatchGame + Class_BaseGame__EnemyPawns);
                if (EnemyPawns) {
                    auto Items = EnemyPawns->getItems();
                    if (Items) {
                        for (int i = 0; i < EnemyPawns->getSize(); i++) {
                            auto Pawn = Items[i];
                            if (Pawn) {
                                            
                                auto isAlive = *(bool*) ((uintptr_t)Pawn + Pawn_m_IsAlive);
                                if (!isAlive)
                                    continue;

                                auto m_HeadBone = *(Transform **) (Pawn + Class_Pawn__m_HeadBone);
                                if (!m_HeadBone)
                                    continue;

                                auto HeadSc = WorldToScreenPoint(m_HeadBone->get_position());

                                Vector2 v2Middle = Vector2((float) (get_width() / 2), (float) (get_height() / 2));
                                Vector2 v2Loc = Vector2(HeadSc.x, HeadSc.y);

                                if (isInsideFOV((int) HeadSc.x, (int) HeadSc.y)) {
                                    float Distance = Vector2::Distance(v2Middle, v2Loc);

                                    if (Distance < MaxDist) {
                                        result = Pawn;
                                        MaxDist = Distance;
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

    return result;
}

Vector2 pushToScreenBorder(Vector2 Pos, Vector2 screen, int borders, int offset) {
    int x = (int)Pos.x;
    int y = (int)Pos.y;
    if ((borders & 1) == 1) {
        y = 0 - offset;
    }
    if ((borders & 2) == 2) {
        x = (int)screen.x + offset;
    }
    if ((borders & 4) == 4) {
        y = (int)screen.y + offset;
    }
    if ((borders & 8) == 8) {
        x = 0 - offset;
    }
    return Vector2(x, y);
}
int isOutsideSafezone(Vector2 pos, Vector2 screen) {
    Vector2 mSafezoneTopLeft(screen.x * 0.04f, screen.y * 0.04f);
    Vector2 mSafezoneBottomRight(screen.x * 0.96f, screen.y * 0.96f);

    int result = 0;
    if (pos.y < mSafezoneTopLeft.y) {
        result |= 1;
    }
    if (pos.x > mSafezoneBottomRight.x) {
        result |= 2;
    }
    if (pos.y > mSafezoneBottomRight.y) {
        result |= 4;
    }
    if (pos.x < mSafezoneTopLeft.x) {
        result |= 8;
    }
    return result;
}

class FPSCounter {
protected:
    unsigned int m_fps;
    unsigned int m_fpscount;
    long m_fpsinterval;

public:
    FPSCounter() : m_fps(0), m_fpscount(0), m_fpsinterval(0) {
    }

    void update() {
        m_fpscount++;

        if (m_fpsinterval < time(0)) {
            m_fps = m_fpscount;

            m_fpscount = 0;
            m_fpsinterval = time(0) + 1;
        }
    }

    unsigned int get() const {
        return m_fps;
    }
};

FPSCounter fps;

void DrawBoxEnemy(ImDrawList *draw, ImVec2 X, ImVec2 Y, float thicc, int color) {
    draw->AddLine({X.x, X.y}, {Y.x, Y.y}, color, thicc);
}


void DrawESP(ImDrawList *draw, int sWidth, int sHeight,float density) {
    
    std::string sFPS = OBFUSCATE("ZAI VIP || FPS: ");
    sFPS += std::to_string(fps.get());

    draw->AddText({((float) density / 10.0f), 40},IM_COL32(0, 255, 0, 255),sFPS.c_str());

    
    if (Config.Aim.By == EAim::Crosshair) {
        draw->AddCircle(ImVec2(sWidth / 2, sHeight / 2), Config.Aim.Size*1.0f, ToColor(Config.ColorsESP.PovC), 0, 0.0f);
    }

    if (Config.ESPMenu.ESP) {
        auto Gameplay_get_MatchGame = (uintptr_t (*)()) (Class_Gameplay__get_MatchGame);
        auto get_MatchGame = Gameplay_get_MatchGame();      
        if (Tools::IsPtrValid((void *) get_MatchGame)) {           
                if (!isEspReady) {
                    botCount = 0;
                    playerCount = 0;
                    auto EnemyPawns = *(List<uintptr_t> **) (get_MatchGame + Class_BaseGame__EnemyPawns);
                    if (Tools::IsPtrValid(EnemyPawns) && EnemyPawns->getSize()) {

                        for (int i = 0; i < EnemyPawns->getSize(); i++) {
                            auto Pawn = EnemyPawns->getItems()[i];
                            
                            if (Tools::IsPtrValid((void *) Pawn)) {
                                
                                auto Gameplay_get_LocalPawn = (uintptr_t (*)()) (Class_Gameplay__get_LocalPawn);
                                auto LocalPawn = Gameplay_get_LocalPawn();
                            if (Tools::IsPtrValid((void *) LocalPawn)) {
                                Vector3 MyPos{0, 0, 0};
                
                                auto local_m_Mesh = *(Transform **) (LocalPawn + Class_Pawn__m_Mesh);
                            if (Tools::IsPtrValid(local_m_Mesh)) {
                                MyPos = local_m_Mesh->get_position();
                            }
                                auto m_PlayerInfo = *(uintptr_t *) (Pawn + Class_Pawn__m_PlayerInfo);
                                
                                if (Tools::IsPtrValid((void *) m_PlayerInfo)) {
                                    auto m_AttackableInfo = *(uintptr_t *) (Pawn + Class_AttackableTarget__m_AttackableInfo);
                                    int CurHP = (int) *(float *) (m_AttackableInfo + Class_AttackableTarget__m_Health);
                                    int MaxHP = (int) *(float *) (m_AttackableInfo + Class_AttackableTarget__m_MaxHealth);
                                    
                                    auto m_HeadBone = *(Transform **) (Pawn + Class_Pawn__m_HeadBone);                          
                                    if (!Tools::IsPtrValid(m_HeadBone))
                                        continue;                   
                                        
                                    auto m_Mesh = *(Transform **) (Pawn + Class_Pawn__m_Mesh);
                                    if (!m_Mesh)
                                        continue;
                                        
                                    if (!*(bool *) (Pawn + Pawn_m_IsAlive))
                                        continue;
                                        
                                    bool isBot = *(bool*) ((uintptr_t)Pawn + Class_Pawn__m_IsBot);                              
                                    if (isBot) {
                                        botCount++;
                                    } else {
                                        playerCount++;
                                    } 
                                    

                                    auto HeadSc = WorldToScreenPoint(m_HeadBone->get_position());
                                    auto RootSc = WorldToScreenPoint(m_Mesh->get_position());
                                                  
                                    float Distance = Vector3::Distance(MyPos, m_HeadBone->get_position());
                                    if (Distance > 500.0f)
                                        continue;
                                    Vector2 screen(sWidth, sHeight);
                                    Vector2 location(RootSc.x,HeadSc.y);
                                    float mScale = sHeight / (float) 1080;   
                                    float boxHeight = abs(HeadSc.y - RootSc.y);
                                    float boxWidth = boxHeight * 0.65f;                                   
                                    
                                    float magic_number = (Distance);
                                    float mx = (sWidth / 6) / magic_number;

                                    float healthLength = sWidth / 20;
                                    if (healthLength < mx)
                                        healthLength = mx;
                                                                                                        
                                    Rect PlayerRect(HeadSc.x - (boxWidth / 2), sHeight - HeadSc.y, boxWidth, boxHeight);

                                                                int SCOLOR;
                            int SCOLOR2;
                            SCOLOR = IM_COL32(0, 255, 0, 255);
                            SCOLOR2 = IM_COL32(255, 0, 0, 255);
                          
                            
                                    if (HeadSc.z > 0) {
                                 
                                    // Esp Player Line
                                    if (Config.ESPMenu.isPlayerLine) {
                                        if (isBot) {
                                                 draw->AddLine(ImVec2(sWidth / 2, 80), ImVec2(HeadSc.x, sHeight - HeadSc.y), SCOLOR, 1.7f);
                                              } else {
                                                draw->AddLine(ImVec2(sWidth / 2, 80), ImVec2(HeadSc.x, sHeight - HeadSc.y), SCOLOR2, 1.7f);
                                            }
                                 }
                                    if (Config.ESPMenu.isPlayerName || Config.ESPMenu.isPlayerDist || Config.ESPMenu.isPlayerHealth) {
                                        DrawBoxEnemy(draw, ImVec2(HeadSc.x - healthLength, sHeight - HeadSc.y - 28), ImVec2(HeadSc.x + healthLength, sHeight - HeadSc.y - 28), 22, IM_COL32(0, 0, 0, 190));
                                    }

                                    
                                    // Esp Player Health     
                                    if (Config.ESPMenu.isPlayerHealth) {
                     
                                    if (Config.ESPMenu.Heal == Health1::HTop) {  
                                      long curHP_Color = IM_COL32(std::min(((510 * (MaxHP - CurHP)) / MaxHP), 250),std::min((510 * CurHP) / MaxHP, 255), 0, 255);
                                      long HPColor = IM_COL32(255,255,255,150);
                                      long HPRectColor = IM_COL32(255,255,255,150);
                                         
                                      ImVec2 vEndFilled = ImVec2(HeadSc.x - healthLength + (2 * healthLength) * CurHP / 100, sHeight - HeadSc.y - 15);
                                      DrawBoxEnemy(draw, ImVec2(HeadSc.x - healthLength, sHeight - HeadSc.y - 15), vEndFilled, 4, curHP_Color);
                                      draw->AddRect(ImVec2(HeadSc.x - healthLength, sHeight - HeadSc.y - 18), ImVec2(HeadSc.x + healthLength, sHeight - HeadSc.y - 12), IM_COL32(0, 0, 0, 255));                                                    
                                    }
                                    
                                    if (Config.ESPMenu.Heal == Health1::Side) {  
                                      float boxHeight = abs(HeadSc.y - RootSc.y);
                                      float boxWidth = boxHeight * 0.65f;
                                      float PercentHP = ((float)CurHP * boxHeight) / (float)MaxHP;
     
                                      ImVec2 vX = {HeadSc.x + (boxWidth / 2), sHeight - HeadSc.y + boxHeight};
                                      ImVec2 vY = {HeadSc.x + (boxWidth / 2) + 13, vX.y - PercentHP};
                                      draw->AddRectFilled(vX, vY, IM_COL32(0, 255, 0, 255));
                                        
                                      ImVec2 vA = {HeadSc.x + (boxWidth / 2), sHeight - HeadSc.y};
                                      ImVec2 vB = {HeadSc.x + (boxWidth / 2) + 15, vA.y + boxHeight};
                                      draw->AddRect(vA, vB, IM_COL32(0, 0, 0, 255), 1.4f);                      
                                    }
                                    
                                    
								}
                                    
                                    
                                    // Esp Player Distance
                                    if (Config.ESPMenu.isPlayerDist) {           
                                        std::string s;
                                        //s = "[";
                                        s += std::to_string((int) Distance);
                                        s += "M";                                                                
                                        //float mWidth = density / 3.1f; 
                                        float a = 30;
                                        if (Distance >= 100) {
                                            a = 35;
                                        }
                                            //draw->AddText(nullptr, 17.f, ImVec2(RootSc.x - mWidth + 119.0f , sHeight - RootSc.y + 0.57f), ToColor(Config.ColorsESP.Distance), s.c_str());
                                            draw->AddText(nullptr, 13.f, ImVec2(HeadSc.x + healthLength - a, sHeight - HeadSc.y - 37.0f), IM_COL32(255, 255, 255, 255), s.c_str());
                                    }
                                    
                                    // Esp Player Name
                                    if (Config.ESPMenu.isPlayerName) {                                 
                                        auto m_NickName = *(String **) (m_PlayerInfo + Class_PlayerInfo__m_NickName);                               
                                        char ws[0xFF] = {0};

                                        if (m_NickName) {
                                            snprintf(ws, sizeof(ws), OBFUSCATE(" %s "), m_NickName->CString());
                                        }
                                  
                                        std::string nickname;
                                        nickname += ws;
                                        float a = 5;
                                        
                                        draw->AddText(nullptr, 13.f, ImVec2(HeadSc.x - healthLength + a, sHeight - HeadSc.y - 37.0f), ToColor(Config.ColorsESP.NameC), nickname.c_str());
                         
                                    }
                                
                                    
                                    // Esp Player Box
                                    if (Config.ESPMenu.isPlayerBox) {
                                        
                                        if (Config.ESPMenu.Boxer == BoxNig::Box) {  
                                        float boxHeight = abs(HeadSc.y - RootSc.y);
                                        float boxWidth = boxHeight * 0.65f;
										long bCurHP_Color = IM_COL32(std::min(((510 * (MaxHP - CurHP)) / MaxHP), 250),std::min((510 * CurHP) / MaxHP, 255), 0, 35);
                                        ImVec2 vStart = {HeadSc.x - (boxWidth / 2), sHeight - HeadSc.y};
                                        ImVec2 vEnd = {vStart.x + boxWidth, vStart.y + boxHeight};
                                        draw->AddRect(vStart, vEnd, ToColor(Config.ColorsESP.BoxC), 1.4f);
										draw->AddRectFilled(vStart, vEnd, bCurHP_Color);
                                    }
                                    if (Config.ESPMenu.Boxer == BoxNig::Cen) {  
                                        int x = RootSc.x - (boxWidth / 2);
                                        int y = sHeight - HeadSc.y;
                                        int w = boxWidth;
                                        int h = boxHeight;
                                        int iw = w / 4;
                                        int ih = h / 4;                                                             
                                        //Top
                                        draw->AddLine(ImVec2(x, y), ImVec2(x + iw, y), ToColor(Config.ColorsESP.BoxC), 1.8f);
                                        draw->AddLine(ImVec2(x + w - iw, y), ImVec2(x + w, y), ToColor(Config.ColorsESP.BoxC), 1.8f);
                                        draw->AddLine(ImVec2(x, y), ImVec2(x, y + ih), ToColor(Config.ColorsESP.BoxC), 1.8f);
                                        draw->AddLine(ImVec2(x + w - 1, y), ImVec2(x + w - 1, y + ih), ToColor(Config.ColorsESP.BoxC), 1.8f);
                                        // bottom
                                        draw->AddLine(ImVec2(x, y + h), ImVec2(x + iw, y + h), ToColor(Config.ColorsESP.BoxC), 1.8f);
                                        draw->AddLine(ImVec2(x + w - iw, y + h), ImVec2(x + w, y + h), ToColor(Config.ColorsESP.BoxC), 1.8f);
                                        draw->AddLine(ImVec2(x, y + h - ih), ImVec2(x, y + h), ToColor(Config.ColorsESP.BoxC), 1.8f);
                                        draw->AddLine(ImVec2(x + w - 1, y + h - ih), ImVec2(x + w - 1, y + h), ToColor(Config.ColorsESP.BoxC), 1.8f);
                                        
                                    }
								  
                                    }
                                    
                                   // Esp Player Alert 360°
                                    if (Config.ESPMenu.Count) { 
                                        int borders = isOutsideSafezone(location, screen);
                                        if (borders != 0){
                                            sprintf(extra,"%0.0fM", Distance);
                                            Vector2 hintDotRenderPos = pushToScreenBorder(location, screen, borders, (int)((mScale * 100) / 3));
                                            Vector2 hintTextRenderPos = pushToScreenBorder(location, screen, borders, -(int)((mScale * 36)));
                                            m_Canvas->drawFilledCircle(hintDotRenderPos.x,hintDotRenderPos.y, (mScale * 75), IM_COL32(0, 255, 0, 80));
                                            m_Canvas->drawText(extra, hintTextRenderPos.x,hintTextRenderPos.y, 20, IM_COL32(255, 255, 255, 255));
                                        }
                                    } 

                                    }
                                }
                            }
                        }
                    } // End Loop


                }
            }
        }
        
       //Esp Player Count
       if (Config.ESPMenu.Count) {
       ImGui::GetForegroundDrawList()->AddRectFilled({sWidth /2-50,40},{sWidth /2,80},ImColor(255, 0, 0,110));
       ImGui::GetForegroundDrawList()->AddRectFilled({sWidth /2+50,40},{sWidth /2,80},ImColor(3, 255, 40,110)); 
       sprintf(extra, "%d", playerCount);
       ImGui::GetForegroundDrawList()->AddText({sWidth /2-35,45}, ImColor(255,255,255), extra);
       sprintf(extra, "%d", botCount);
       ImGui::GetForegroundDrawList()->AddText({sWidth /2+15,45}, ImColor(255,255,255), extra);
     }
     fps.update();
  }
}
        

    

void (*oWeaponFireComponent_Instant_CreateBulletLine)(uintptr_t thiz, Vector3 startPos, Vector3 dir, bool isDualFire);
void WeaponFireComponent_Instant_CreateBulletLine(uintptr_t thiz, Vector3 startPos, Vector3 dir, bool isDualFire) {
    if (Config.Aim.Enable) {
        auto Gameplay_get_MatchGame = (uintptr_t (*)()) (Class_Gameplay__get_MatchGame);
        auto get_MatchGame = Gameplay_get_MatchGame();
        if (Tools::IsPtrValid((void *) get_MatchGame)) {
            auto Gameplay_get_LocalPawn = (uintptr_t (*)()) (Class_Gameplay__get_LocalPawn);
                auto LocalPawn = Gameplay_get_LocalPawn();
                if (LocalPawn) {
                    bool bTriggerReady =  Config.Aim.Trigger == EAimTrigger::None;
                     if (Config.Aim.Trigger == EAimTrigger::Shooting) {
                        auto Pawn_get_IsFiring = (bool (*)(uintptr_t)) (Class_Pawn_get_IsFiring);
                        bTriggerReady = Pawn_get_IsFiring(LocalPawn);
                    } else if (Config.Aim.Trigger == EAimTrigger::Scoping) {
                        auto Pawn_IsAiming = (bool (*)(uintptr_t)) (Class_Pawn_IsAiming);
                        bTriggerReady = Pawn_IsAiming(LocalPawn);
                    }
                    if (bTriggerReady) {
                        uintptr_t Target = 0;
                        if (Config.Aim.By == EAim::Distance) {  
                            Target = GetClosestTarget();
                        }
                       if (Config.Aim.By == EAim::Crosshair) {  
                            Target = GetInsideFOVTarget();
                        }
                        if (Target) {           
                            Vector3 targetPos;
                            if (Config.Aim.Target == EAimTarget::Heads) {  
                                auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);
                                if (!m_HeadBone)
                                    return oWeaponFireComponent_Instant_CreateBulletLine(thiz, startPos, dir, isDualFire);
                                    targetPos = m_HeadBone->get_position();
                            }
                            if (Config.Aim.Target == EAimTarget::Chests) {  
                                    auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);
                                if (!m_HeadBone)
                                    return oWeaponFireComponent_Instant_CreateBulletLine(thiz, startPos, dir, isDualFire);
                                    targetPos = m_HeadBone->get_position();
                                    targetPos.y -= 0.2f;
                            }
                                                 if (Config.Aim.Target == EAimTarget::Body) {  
        auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);
        if (!m_HeadBone)
                                    return oWeaponFireComponent_Instant_CreateBulletLine(thiz, startPos, dir, isDualFire);
        targetPos = m_HeadBone->get_position();
        targetPos.y -= 0.4f;
       }
                            
                            auto main = Camera::get_main();
                            if (main) {
                                auto mainView = ((Component *) main)->get_transform();
                                if (mainView) {
                                     dir = targetPos - mainView->get_position();
                                }
                            }
                        }
                    }
                }
            }
        }
        return oWeaponFireComponent_Instant_CreateBulletLine(thiz, startPos, dir, isDualFire);
}
void (*oWeaponFireComponent_Instant_CreateBulletProjectile)(void* thiz, Vector3 startPos, Vector3 dir, void* weaponImpact, int itemID, int flySmokeAssetID, bool enableVirtualStartPos, Vector3 virtualStartPos);
void WeaponFireComponent_Instant_CreateBulletProjectile(void* thiz, Vector3 startPos, Vector3 dir, void* weaponImpact, int itemID, int flySmokeAssetID, bool enableVirtualStartPos, Vector3 virtualStartPos) {
    if (Config.Aim.Enable) {
         auto Gameplay_get_MatchGame = (uintptr_t (*)()) (Class_Gameplay__get_MatchGame);
  auto get_MatchGame = Gameplay_get_MatchGame();
  if (Tools::IsPtrValid((void *) get_MatchGame)) {
   auto Gameplay_get_LocalPawn = (uintptr_t (*)()) (Class_Gameplay__get_LocalPawn);
                auto LocalPawn = Gameplay_get_LocalPawn();
    if (Tools::IsPtrValid((void *) LocalPawn)) {
     bool bTriggerReady = Config.Aim.Trigger == 0;
     if (Config.Aim.Trigger == Shooting) {
      auto Pawn_get_IsFiring = (bool (*)(uintptr_t)) (Class_Pawn_get_IsFiring);
      bTriggerReady = Pawn_get_IsFiring(LocalPawn);
     } else if (Config.Aim.Trigger == Scoping) {
      auto Pawn_IsAiming = (bool (*)(uintptr_t)) (Class_Pawn_IsAiming);
      bTriggerReady = Pawn_IsAiming(LocalPawn);
     }
     if (bTriggerReady) {
      uintptr_t Target = 0;
      if (Config.Aim.By == EAim::Distance) {
       Target = GetClosestTarget();
      }
      if (Config.Aim.By == EAim::Crosshair) {
       Target = GetInsideFOVTarget();
      }
      if (Target) {
       Vector3 targetPos;
                            if (Config.Aim.Target == EAimTarget::Heads) {  
        auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);
       if (!m_HeadBone)
       return oWeaponFireComponent_Instant_CreateBulletProjectile(thiz, startPos, dir, weaponImpact, itemID, flySmokeAssetID, enableVirtualStartPos, virtualStartPos);
        targetPos = m_HeadBone->get_position();
       }
                            if (Config.Aim.Target == EAimTarget::Chests) {  
        auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);
        if (!m_HeadBone)
           return oWeaponFireComponent_Instant_CreateBulletProjectile(thiz, startPos, dir, weaponImpact, itemID, flySmokeAssetID, enableVirtualStartPos, virtualStartPos);
        targetPos = m_HeadBone->get_position();
        targetPos.y -= 0.2f;
       }
                            if (Config.Aim.Target == EAimTarget::Body) {  
        auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);
        if (!m_HeadBone)
           return oWeaponFireComponent_Instant_CreateBulletProjectile(thiz, startPos, dir, weaponImpact, itemID, flySmokeAssetID, enableVirtualStartPos, virtualStartPos);
        targetPos = m_HeadBone->get_position();
        targetPos.y -= 0.4f;
       }
       auto main = Camera::get_main();
       if (main) {
        auto mainView = ((Component *) main)->get_transform();
        if (mainView) {
         dir = targetPos - mainView->get_position();
        }
       }
      }
     }
    }
   }
  } 
       return oWeaponFireComponent_Instant_CreateBulletProjectile(thiz, startPos, dir, weaponImpact, itemID, flySmokeAssetID, enableVirtualStartPos, virtualStartPos);
}

void *Main_Thread() {
    while (m_Il2Cpp) {
        auto t1 = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count();
        
        auto Gameplay_get_MatchGame = (uintptr_t (*)()) (Class_Gameplay__get_MatchGame);
        auto baseGame = Gameplay_get_MatchGame();
        if (Tools::IsPtrValid((void *) baseGame)) {
            auto Gameplay_get_LocalPawn = (uintptr_t (*)()) (Class_Gameplay__get_LocalPawn);
                auto LocalPawn = Gameplay_get_LocalPawn();
                if (LocalPawn) {                
                    if (Config.Aim.SilentBot) {
                        bool bTriggerReady =  Config.Aim.Trigger == EAimTrigger::None;
                        if (Config.Aim.Trigger == EAimTrigger::Shooting) {
                        auto Pawn_get_IsFiring = (bool (*)(uintptr_t)) (Class_Pawn_get_IsFiring);
                        bTriggerReady = Pawn_get_IsFiring(LocalPawn);
                        } else if (Config.Aim.Trigger == EAimTrigger::Scoping) {
                               auto Pawn_IsAiming = (bool (*)(uintptr_t)) (Class_Pawn_IsAiming);
                               bTriggerReady = Pawn_IsAiming(LocalPawn);
                        }
                        if (bTriggerReady) {
                        uintptr_t Target = 0;
                        if (Config.Aim.By == EAim::Distance) {  
                            Target = GetClosestTarget();
                        }
                       if (Config.Aim.By == EAim::Crosshair) {  
                            Target = GetInsideFOVTarget();
                       }
                            
                            if (Target) {                               
                                Vector3 targetPos;
                            if (Config.Aim.Target == EAimTarget::Heads) {  
                                     auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);                               
                                if (!m_HeadBone)
                                    continue; 
                                    targetPos = m_HeadBone->get_position();
                               }
                            if (Config.Aim.Target == EAimTarget::Chests) {  
                                    auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);
                                if (!m_HeadBone)
                                    continue;
                                    targetPos = m_HeadBone->get_position();
                                    targetPos.y -= 0.2f;
                            }
                                if (Config.Aim.Target == EAimTarget::Body) {  
        auto m_HeadBone = *(Transform **) (Target + Class_Pawn__m_HeadBone);
        if (!m_HeadBone)
            continue;
        targetPos = m_HeadBone->get_position();
        targetPos.y -= 0.4f;
        }
                            
                                auto main = Camera::get_main();
                                if (main) {
                                    auto mainView = ((Component *) main)->get_transform();
                                    if (mainView) {
                                        auto Pawn_set_AimRotation = (void (*)(uintptr_t, Quaternion)) (Class_Pawn_set_AimRotation);
                                        Pawn_set_AimRotation(LocalPawn, Quaternion::LookRotation(targetPos - mainView->get_position(), Vector3::Up()));
                                    }
                                }
                            }
                        }
                    }
                }
            }
        
        auto td = std::chrono::duration_cast<std::chrono::milliseconds>(std::chrono::system_clock::now().time_since_epoch()).count() - t1;
        std::this_thread::sleep_for(std::chrono::milliseconds(std::max(std::min(0LL, SLEEP_TIME - td), SLEEP_TIME)));
    }
}




#pragma clang diagnostic pop
